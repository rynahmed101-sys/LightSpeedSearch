'use client';

import { useMemo, useState } from 'react';
import { activeViews, runLocalQuery, type ResultView, type SearchResult } from '@/lib/search-data';

const limitationNote =
  'Current search limitations: Search currently focuses on dictionary-based word indexing, word combinations, and word-frequency patterns. Full semantic relationship analysis, special-character and symbolic search, and comprehensive coverage across all content types are not yet supported. Results and verification links should be treated as leads to inspect, not automatic proof of a claim.';

export default function Page() {
  const [query, setQuery] = useState('dictionary first');
  const [activeView, setActiveView] = useState<ResultView>('Consensus');

  const matchingResults = useMemo(() => runLocalQuery(query), [query]);
  const visibleResults = activeView === 'Consensus'
    ? matchingResults.filter((result) => result.view === 'Consensus')
    : matchingResults.filter((result) => result.view === activeView);

  return (
    <main className="page-shell">
      <header className="topbar">
        <div>
          <p className="eyebrow">EWE + LSS</p>
          <h1>Dictionary-first discovery dashboard</h1>
        </div>
        <div className="status-pill">Local prototype</div>
      </header>

      <section className="search-panel">
        <div className="search-input-row">
          <input
            aria-label="Search query"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search dictionary terms, historical dates, or evidence topics"
          />
          <button type="button">Search</button>
        </div>
        <p className="limitation-note">{limitationNote}</p>
      </section>

      <section className="summary-grid">
        <article className="metric-card">
          <span>Discovery status</span>
          <strong>Indexed</strong>
          <small>Dictionary and document postings are initialized.</small>
        </article>
        <article className="metric-card">
          <span>Verification status</span>
          <strong>Partially assessed</strong>
          <small>Evidence is inspected, not automatically verified.</small>
        </article>
        <article className="metric-card">
          <span>Provider overlap</span>
          <strong>3 sources</strong>
          <small>Shared discovery is visible and non-independently weighted.</small>
        </article>
      </section>

      <section className="view-tabs" aria-label="Result views">
        {activeViews.map((view) => (
          <button
            key={view}
            type="button"
            className={view === activeView ? 'tab active' : 'tab'}
            onClick={() => setActiveView(view)}
          >
            {view}
          </button>
        ))}
      </section>

      <section className="results-layout">
        <div className="results-panel">
          <div className="results-header">
            <h2>{activeView}</h2>
            <span>{visibleResults.length} result(s)</span>
          </div>

          {visibleResults.length === 0 ? (
            <div className="empty-state">No results match the current query for this view.</div>
          ) : (
            <div className="result-list">
              {visibleResults.map((result: SearchResult) => (
                <article key={result.id} className="result-card">
                  <div className="result-topline">
                    <span className="badge">{result.provider}</span>
                    <span className="meta">{result.category}</span>
                  </div>
                  <h3>{result.title}</h3>
                  <p>{result.snippet}</p>
                  <div className="result-meta-row">
                    <span>Score: {result.score.toFixed(2)}</span>
                    <span>Discovery: {result.discoveryState}</span>
                    <span>Verification: {result.verificationState}</span>
                  </div>
                  <div className="url-row">
                    <a href={result.url} target="_blank" rel="noreferrer">{result.url}</a>
                  </div>
                  <ul className="evidence-list">
                    {result.evidence.map((item) => (
                      <li key={`${result.id}-${item}`}>{item}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          )}
        </div>

        <aside className="sidebar">
          <div className="panel">
            <h3>Discovery vs. verification</h3>
            <p>
              Search discovery tracks what was found and how it was retrieved. Verification tracks whether an inspected
              claim is supported, contradicted, or inconclusive.
            </p>
          </div>
          <div className="panel">
            <h3>Visible source links</h3>
            <ul>
              <li>Original page or archive</li>
              <li>Dataset or reference entry</li>
              <li>Historical search trail</li>
            </ul>
          </div>
          <div className="panel">
            <h3>Transparency</h3>
            <p>Repeated provider hits are treated as overlap, not automatic independent proof.</p>
          </div>
        </aside>
      </section>
    </main>
  );
}
