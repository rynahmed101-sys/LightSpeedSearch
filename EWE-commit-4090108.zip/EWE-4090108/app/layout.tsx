import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'EWE + LSS Discovery Dashboard',
  description: 'Dictionary-first search discovery and evidence overview for EWE and Light Speed Search.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
