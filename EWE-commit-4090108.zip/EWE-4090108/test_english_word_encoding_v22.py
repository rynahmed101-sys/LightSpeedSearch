import itertools
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import english_word_encoding_v22 as encoding


class EncodingTests(unittest.TestCase):
    def test_existing_identity_values_and_case_normalization(self):
        expected = {
            "a": 1,
            "b": 2,
            "cat": 2234,
            "cot": 2612,
            "dog": 3328,
            "cats": 60337,
        }
        for word, identity in expected.items():
            with self.subTest(word=word):
                self.assertEqual(encoding.encode(word)["identity"], identity)
        self.assertEqual(encoding.encode("CAT"), encoding.encode("cat"))

    def test_positive_and_unique_codes_for_exhaustive_short_spellings(self):
        words = [
            "".join(letters)
            for length in range(1, 5)
            for letters in itertools.product("abc", repeat=length)
        ]
        codes = [encoding.encode(word)["identity"] for word in words]
        self.assertTrue(all(code > 0 for code in codes))
        self.assertEqual(len(codes), len(set(codes)))

    def test_round_trip_known_prefix_and_repeated_letter_cases(self):
        words = ("a", "z", "aa", "az", "ba", "zz", "cat", "aaaa", "banana")
        for word in words:
            with self.subTest(word=word):
                code = encoding.encode(word)["identity"]
                self.assertEqual(encoding.decode(code), word)

    def test_round_trip_long_word(self):
        word = "az" * 5000
        code = encoding.encode(word)["identity"]
        self.assertEqual(encoding.decode(code), word)

    def test_decoder_rejects_invalid_codes(self):
        for code in (0, -1, 27, 54, 729):
            with self.subTest(code=code):
                with self.assertRaises(ValueError):
                    encoding.decode(code)
        for code in (True, 1.0, "1"):
            with self.subTest(code=code):
                with self.assertRaises(TypeError):
                    encoding.decode(code)

    def test_cli_reports_undecodable_identity_without_traceback(self):
        script = Path(encoding.__file__)
        completed = subprocess.run(
            [sys.executable, str(script), "--decode", "27"],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 2)
        self.assertIn("identity is not a valid spelling code", completed.stderr)
        self.assertNotIn("Traceback", completed.stderr)

    def test_invalid_spellings_remain_rejected(self):
        for word in ("", "hello world", "can't", "ice-cream", "café", "123"):
            with self.subTest(word=word):
                with self.assertRaises(ValueError):
                    encoding.encode(word)

    def test_similarity_remains_separate_from_identity(self):
        comparison = encoding.compare("CAT", "cot")
        self.assertEqual(comparison["edit_distance"], 1)
        self.assertEqual(comparison["normalized_spelling_similarity"], 0.6667)
        self.assertEqual(encoding.edit_distance("", "abc"), 3)
        self.assertEqual(encoding.edit_distance("abc", ""), 3)

    def test_wordlist_audit_counts_normalization_and_round_trips(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "words.txt"
            path.write_text("Cat\ncat\nice-cream\ncafé\n# note\n\n", encoding="utf-8")
            report = encoding.audit_wordlist(path)

        self.assertEqual(report["physical_lines"], 6)
        self.assertEqual(report["candidate_entries_before_normalization"], 4)
        self.assertEqual(report["accepted_entries_after_normalization"], 2)
        self.assertEqual(report["unique_normalized_spellings"], 1)
        self.assertEqual(report["rejected_entries_count"], 2)
        self.assertEqual(
            {item["value"]: item["reason"] for item in report["rejected_entries"]},
            {
                "ice-cream": "contains non-letter ASCII characters",
                "café": "contains non-ASCII characters",
            },
        )
        self.assertEqual(report["normalization_variants"], {"cat": ["Cat", "cat"]})
        self.assertTrue(report["round_trip_check_passed"])
        self.assertEqual(report["round_trip_checked_spellings"], 1)

    def test_long_identity_has_json_serialization_path(self):
        word = "a" * 10000
        rendered = encoding.render_json(encoding.encode(word))
        decoded_json = json.loads(rendered)
        self.assertEqual(decoded_json["word"], word)
        self.assertIsInstance(decoded_json["identity"], str)
        self.assertGreater(len(decoded_json["identity"]), 4300)
        self.assertTrue(decoded_json["serialization_notes"])
        parsed_identity = encoding.parse_identity_argument(decoded_json["identity"])
        self.assertEqual(encoding.decode(parsed_identity), word)


if __name__ == "__main__":
    unittest.main()