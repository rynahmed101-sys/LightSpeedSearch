# English Word Encoding v2.2 Audit

## Mathematical result

After `normalize`, every spelling is a nonempty sequence of letters with values
in 1 through 26. For values `v_1 ... v_n`, the existing encoder computes

`N = v_1 * 27^(n-1) + ... + v_(n-1) * 27 + v_n`.

This is the ordinary base-27 positional representation with digits 1 through
26. Its most significant digit is nonzero, so the representation has no
leading-zero ambiguity. Repeated division by 27 recovers the digits in reverse
order. Consequently every valid spelling has a positive code, and two
different normalized spellings cannot have the same code. This is a proof for
the defined input domain, not a claim that integer magnitudes represent
linguistic similarity.

`decode` accepts only a built-in integer. Zero and negative integers are
rejected; positive integers whose base-27 representation contains a zero digit
are also rejected because no spelling maps to them. Booleans, strings, and
other non-integer objects are rejected with `TypeError`. The CLI reads decimal
identities in chunks, so it can accept codes larger than Python's normal
decimal-digit parsing limit.

Normalization trims surrounding whitespace, validates ASCII letters, and
lowercases them. Thus `CAT` and `cat` encode identically. Interior whitespace,
punctuation, digits, accented letters, and empty strings remain invalid.

Python integers are arbitrary precision, so code size is not fixed-width.
Encoding and decoding perform one arithmetic step per letter; the integer
operations grow with the number of letters. A 10,000-character spelling was
encoded, decoded, and passed through JSON output in the regression suite. If
Python refuses to convert an unusually large integer to decimal, JSON output
uses a decimal string for that integer and includes a `serialization_notes`
field; ordinary-size outputs retain integer-valued JSON identities.

## Similarity representations

- **Letter-value vectors:** `[1, 3, 20]` represents `cat`. The full sequence
  preserves the exact ordered letters and therefore spelling identity. A
  numerical vector metric such as Euclidean distance imposes arbitrary
  distances on letter labels (`a` to `b` equals `y` to `z` only by the chosen
  numbering). Words of different lengths have different vector dimensions;
  padding or alignment would be an additional modeling choice.
- **Character n-grams:** a word can be represented by its set or frequency
  vector of adjacent character groups, such as bigrams `ca`, `at` for `cat`.
  N-grams capture local spelling patterns and can be compared across lengths
  with measures such as Jaccard or cosine similarity. A fixed n-gram summary
  generally loses global order and is not a unique word identity; words shorter
  than `n` have no unpadded n-grams. Boundary markers or a different `n` alter
  these properties.
- **Levenshtein distance:** the existing comparison counts the minimum
  insertions, deletions, and substitutions needed to transform one spelling
  into another. It preserves a notion of ordered edit effort but the final
  scalar loses the edit path and letter identities. The reported score is
  `1 - distance / max(lengths)`, in `[0, 1]` for the nonempty normalized inputs.
  It is spelling similarity only, not semantic similarity. The implementation
  uses `O(m*n)` time and `O(min(m,n))` auxiliary memory.

The base-27 integer is an identity code, not a similarity coordinate. For
example, `cat` and `cot` have edit distance 1, but their integer difference has
no linguistic interpretation. Similar spelling does not establish similar
meaning.

## Encoding verification

The encoding-specific `unittest` coverage exercises known legacy codes, case
folding, all 120 strings of lengths 1 through 4 over `abc`, short and long
round trips, invalid codes and spellings, prefix/repeated-letter cases,
similarity behavior, audit rejection detail, and long-integer JSON conversion.
The integrated repository suite also exercises store/index synchronization,
evidence retrieval, and verification.

The dataset audit results are in
[`data/esdb-60-A-1-audit.json`](data/esdb-60-A-1-audit.json):

- 109,143 candidate entries before normalization (109,143 physical lines).
- 90,520 accepted entries after trimming and ASCII validation, including
  duplicates.
- 89,048 unique lowercase spellings.
- 1,472 duplicate occurrences beyond the first normalized entry; 1,440 groups
  contain distinct raw forms that collapse under lowercase normalization.
- 18,623 rejected entries: 18,365 contain non-letter ASCII characters and 258
  contain non-ASCII characters. The report records every rejected value, line,
  and reason.
- 89,048 distinct codes for 89,048 unique spellings; no collisions.
- All 89,048 unique spellings decoded back to the original normalized spelling.

The case-variant groups describe differences erased by this normalizer. The
exported plain-text list does not retain relationships between alternate
spellings, and this American-only audit does not identify British/American
variant pairs. The list also does not reliably label proper names,
abbreviations, or non-English terms. Those categories were not classified;
their absence from the report is not evidence that the list contains none.

## Reproduction and limits

Run the code regression checks from the repository root:

```sh
python3 -m unittest discover -v
python3 english_word_encoding_v22.py --self-test
```

Regenerate the audit from the preserved dataset and its provenance:

```sh
python3 english_word_encoding_v22.py \
  --wordlist data/esdb-60-A-1.txt \
  --provenance data/esdb-60-A-1-provenance.json \
  --report data/esdb-60-A-1-audit.json
```

The provenance file pins ESDB to an immutable upstream commit, records the
retrieval date, exact upstream export command, license notice, and SHA-256 of
the preserved input. The upstream license is a custom MIT-like permission, not
a standard SPDX license; the complete upstream copyright/permission text is
preserved in `data/ESDB-Copyright.txt`. Review that notice for the intended
distribution context.

This is an audit of one curated American English speller list, not a count or
definition of all English vocabulary. Coverage, dialect, variant level, and
editorial choices belong to the dataset. The next useful experiment is to
preserve ESDB's variant metadata (or export a matching British list), create
explicit dialect-variant pairs, and compare n-gram and normalized edit-distance
scores against those labels, stratified by word length. That would evaluate
spelling-variant detection, not meaning.

## Integrated dataset and verification audit

The dataset store assigns monotonically increasing change IDs and attaches a
store generation to each journal event. The index checkpoint denotes the last
change fully represented by committed postings and statistics. Index
synchronization validates journal continuity and retention metadata, stages
changes on a copy, and checks the source version/generation before commit.
Uninitialized indexes, insufficient history, or inconsistent checkpoints
rebuild from a snapshot; an update failure cannot advance the checkpoint.
`last_sync_mode`, `last_sync_reason`, `full_rebuild_count`,
`incremental_sync_count`, and `noop_sync_count` expose the actual path taken.

Temporal word frequency is distinct from numeric metrics. The API preserves
inclusive start/end boundaries, requires both boundaries, reports excluded
timestamps, and returns no relative ratio for a zero baseline. Numeric sorting
and date/string ordering use explicit homogeneous-type rules with stable
record-ID ties; invalid mixed types and mixed timezone awareness are errors.

The verification engine treats finite-solver satisfiability as a property of
the constructed model, not proof of the source claim. Only complete evidence
for the supported numeric sequence predicates can yield `VERIFIED` or
`REFUTED`. Truncation, missing values, uncovered records, and insufficient
evidence remain `INCONCLUSIVE`; unsupported predicates and technical failures
are reported separately. The current scope policy is intentionally
conservative: lexical candidates must cover the entire dataset, because a
general query-scope resolver is not implemented.

Benchmark timings separate full index construction, full-scan and already
built-index queries, incremental mutations, post-mutation rebuilds, temporal
comparisons, and verification retrieval/solver/end-to-end work. They use fixed
seeds, repeated samples, medians, and interquartile range; result equivalence
is checked instead of asserting uncontrolled speed thresholds.

Run all integrated regressions with `python3 -m unittest -q`; run the
reproducible synthetic timing report with `python3 benchmark_lookup.py`.
Dataset/index state is in-memory and not crash-durable. Direct mutation of
records or journal fields bypasses version tracking and is unsupported.