"""Compatibility wrapper exposing the legacy finite-domain solver.

This repository keeps the original solver implementation in the file named
``constraint_information 2.py`` because of the project history, but most code and
tests expect the more conventional import path ``constraint_information``.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

_MODULE_PATH = Path(__file__).with_name("constraint_information 2.py")
_SPEC = importlib.util.spec_from_file_location("constraint_information_legacy", _MODULE_PATH)
if _SPEC is None or _SPEC.loader is None:  # pragma: no cover
    raise ImportError(f"Unable to load solver module from {_MODULE_PATH}")

_module = importlib.util.module_from_spec(_SPEC)
sys.modules[_SPEC.name] = _module
_SPEC.loader.exec_module(_module)

ConstraintSolver = _module.ConstraintSolver
Constraint = _module.Constraint
SoftConstraint = _module.SoftConstraint
PropagationResult = _module.PropagationResult
inequality_cycle = _module.inequality_cycle
even_parity_solver = _module.even_parity_solver

__all__ = [
    "Constraint",
    "ConstraintSolver",
    "PropagationResult",
    "SoftConstraint",
    "even_parity_solver",
    "inequality_cycle",
]
