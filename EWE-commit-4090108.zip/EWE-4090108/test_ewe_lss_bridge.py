import tempfile
import unittest
from pathlib import Path

from dataset_store import DatasetStore
from dictionary_reference import DictionaryReference
from ewe_lss_bridge import DictionaryFirstSearch, HistoricalSearchAdapter


class EwelssBridgeTests(unittest.TestCase):
    def test_historical_adapter_builds_expected_urls(self):
        adapter = HistoricalSearchAdapter()
        self.assertIn("duckduckgo.com", adapter.build_url("duckduckgo", "revenue growth", 2020, 2022))
        self.assertIn("2020-01-01..2022-01-01", adapter.build_url("duckduckgo", "revenue growth", 2020, 2022))
        bing_url = adapter.build_url("bing", "revenue growth", 2020, 2022)
        self.assertIn("bing.com/search", bing_url)
        self.assertIn("ez5_", bing_url)
        self.assertRaises(ValueError, adapter.build_url, "unknown", "revenue growth", 2020, 2022)

    def test_dictionary_first_search_uses_supported_terms_and_lss_local_results(self):
        dictionary = DictionaryReference(words=["revenue", "growth", "year", "market", "north", "south"])
        dataset = DatasetStore("bridge-demo")
        dataset.add_record("r1", {"text": "revenue growth north", "year": 2021}, source_location="loc-1")
        dataset.add_record("r2", {"text": "market growth south", "year": 2022}, source_location="loc-2")
        search = DictionaryFirstSearch(dictionary, dataset)
        result = search.discover([
            {"id": "doc-a", "title": "Revenue report", "content": "Revenue growth in north market."},
            {"id": "doc-b", "title": "Market trends", "content": "Growth and revenue matters for markets."},
        ], "revenue growth", limit_results=2, max_candidates=5)

        self.assertIn("revenue", result["supported_tokens"])
        self.assertIn("growth", result["supported_tokens"])
        self.assertGreater(len(result["local_results"]), 0)
        self.assertGreater(len(result["dataset_candidates"]), 0)

    def test_dictionary_first_search_handles_unrecognized_terms(self):
        dictionary = DictionaryReference(words=["revenue", "growth"])
        search = DictionaryFirstSearch(dictionary)
        result = search.search_dataset("mystery term", max_candidates=10)
        self.assertEqual(result["supported_tokens"], [])
        self.assertEqual(result["candidates"], [])

    def test_dictionary_reference_loads_words_from_plain_text_dictionary(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "dictionary.txt"
            path.write_text("revenue\n\n# comment\ngrowth\nmarket\n", encoding="utf-8")
            dictionary = DictionaryReference(source="demo", version="v1", dictionary_path=path)
            self.assertTrue(dictionary.contains("revenue"))
            self.assertTrue(dictionary.contains("growth"))
            self.assertIsNotNone(dictionary.identity_for("market"))

    def test_dictionary_reference_loads_wordnet_archive(self):
        path = Path(__file__).resolve().parent / "wn3.1.dict.tar.gz"
        dictionary = DictionaryReference(source="wordnet", version="3.1", dictionary_path=path)
        self.assertTrue(dictionary.contains("entity"))
        self.assertTrue(dictionary.contains("revenue"))
        self.assertGreater(len(dictionary.entries), 80000)


if __name__ == "__main__":
    unittest.main()
