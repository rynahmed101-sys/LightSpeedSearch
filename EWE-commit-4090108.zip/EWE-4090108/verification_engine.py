from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from constraint_information import ConstraintSolver
from dataset_index import DatasetIndex
from dictionary_reference import DictionaryReference
from evidence_adapter import EvidenceAdapter
from query_locator import QueryLocator


@dataclass(frozen=True)
class VerificationCondition:
    """Structured, explicit verification condition."""

    subject: str | None = None
    metric: str | None = None
    field: str | None = None
    predicate: str | None = None
    ordering: str | None = None
    sort_direction: str = "ascending"
    descending: bool = False
    scope: str | None = None
    year_field: str | None = None
    required_evidence: int | None = None
    evidence_policy: str = "required"
    raw: Any = None

    @classmethod
    def normalize(cls, value: Any) -> "VerificationCondition":
        if isinstance(value, cls):
            return value
        if isinstance(value, Mapping):
            raw = dict(value)
            return cls(
                subject=raw.get("subject") or raw.get("entity") or raw.get("scope"),
                metric=raw.get("metric") or raw.get("field") or raw.get("value_field"),
                field=raw.get("field") or raw.get("value_field") or raw.get("metric"),
                predicate=raw.get("predicate") or raw.get("comparison") or raw.get("type") or raw.get("kind"),
                ordering=raw.get("ordering") or raw.get("order_by") or raw.get("sort_by") or raw.get("sort_key"),
                sort_direction=str(raw.get("sort_direction") or "ascending"),
                descending=raw.get("descending") is True,
                scope=raw.get("scope") or raw.get("subject"),
                year_field=raw.get("year_field") or raw.get("time_field") or "year",
                required_evidence=raw.get("required_evidence"),
                evidence_policy=str(raw.get("evidence_policy") or "required"),
                raw=raw,
            )
        if isinstance(value, str):
            lowered = value.lower().strip()
            predicate = "unsupported"
            if any(token in lowered for token in ("increase", "rising", "grow")):
                predicate = "increase"
            elif any(token in lowered for token in ("decrease", "fall", "drop")):
                predicate = "decrease"
            return cls(subject="value", metric="value", field="value", predicate=predicate, ordering=None, raw=value)
        return cls(subject=None, metric=None, field=None, predicate="unsupported", raw=value)

    def as_mapping(self) -> dict[str, Any]:
        return {
            "subject": self.subject,
            "metric": self.metric,
            "field": self.field,
            "predicate": self.predicate,
            "ordering": self.ordering,
            "sort_direction": self.sort_direction,
            "descending": self.descending,
            "scope": self.scope,
            "year_field": self.year_field,
            "required_evidence": self.required_evidence,
            "evidence_policy": self.evidence_policy,
            "raw": self.raw,
        }


class VerificationStatus(str, Enum):
    VERIFIED = "VERIFIED"
    REFUTED = "REFUTED"
    INCONCLUSIVE = "INCONCLUSIVE"
    UNSUPPORTED = "UNSUPPORTED"
    ERROR = "ERROR"


@dataclass
class VerificationResult:
    status: VerificationStatus
    message: str
    candidates: list[dict[str, Any]] = field(default_factory=list)
    evidence: list[dict[str, Any]] = field(default_factory=list)
    solver_result: dict[str, Any] | None = None
    unknown_tokens: list[str] = field(default_factory=list)
    provenance: list[dict[str, Any]] = field(default_factory=list)
    condition: dict[str, Any] | None = None
    solver_outcome: str | None = None
    evidence_coverage: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.evidence_coverage.setdefault("solver_outcome", self.solver_outcome)
        self.evidence_coverage.setdefault("final_status", self.status.value)
        self.evidence_coverage.setdefault("rationale", self.message)


class VerificationEngine:
    """Orchestrates dictionary lookup, indexing, query location, and verification."""

    def __init__(
        self,
        dictionary_reference: DictionaryReference | None = None,
        dataset_index: DatasetIndex | None = None,
        query_locator: QueryLocator | None = None,
        evidence_adapter: EvidenceAdapter | None = None,
    ) -> None:
        self.dictionary_reference = dictionary_reference or DictionaryReference()
        self.dataset_index = dataset_index
        self.query_locator = query_locator or QueryLocator(self.dictionary_reference, self.dataset_index)
        self.evidence_adapter = evidence_adapter or EvidenceAdapter(self.dictionary_reference)

    def _coerce_records(self, dataset_store: Any) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        for record in dataset_store.iter_records():
            payload = {
                "dataset_id": dataset_store.dataset_id,
                "record_id": getattr(record, "record_id", None),
                "source": getattr(record, "source", None),
                "source_location": getattr(record, "source_location", None),
                "metadata": getattr(record, "metadata", {}),
                "content": getattr(record, "content", record),
            }
            if isinstance(payload["content"], dict):
                payload.update(payload["content"])
            records.append(payload)
        return records

    @staticmethod
    def _query_years(query: str) -> list[int]:
        return [int(value) for value in re.findall(r"20\d{2}", query)]

    def verify_query(
        self,
        dataset_store: Any,
        query: str,
        verification_condition: Any,
        *,
        max_candidates: int | None = 10,
    ) -> VerificationResult:
        normalized_condition = VerificationCondition.normalize(verification_condition)
        condition_mapping = normalized_condition.as_mapping()

        if self.dataset_index is None:
            if not hasattr(dataset_store, "dataset_id"):
                raise ValueError("dataset_store must expose a dataset_id")
            self.dataset_index = DatasetIndex(dataset_store.dataset_id, dictionary_reference=self.dictionary_reference)
            self.query_locator = QueryLocator(self.dictionary_reference, self.dataset_index)

        if hasattr(dataset_store, "sync_index"):
            try:
                dataset_store.sync_index(self.dataset_index)
            except Exception as exc:
                return VerificationResult(
                    VerificationStatus.ERROR,
                    f"The dataset index could not be synchronized: {exc}",
                    condition=condition_mapping,
                    provenance=[{"query": query, "condition": condition_mapping}],
                )

        if hasattr(dataset_store, "index_sync_state") and not dataset_store.index_sync_state.get("synchronized", True):
            return VerificationResult(
                VerificationStatus.ERROR,
                "The dataset index is out of sync with the current records.",
                candidates=[],
                condition=condition_mapping,
                provenance=[{"query": query, "condition": condition_mapping, "dataset_id": getattr(dataset_store, "dataset_id", None), "index_sync_state": getattr(dataset_store, "index_sync_state", {})}],
            )

        verification_snapshot = dataset_store.snapshot()
        if (
            self.dataset_index.dataset_version != verification_snapshot["version"]
            or self.dataset_index.last_applied_change_id != verification_snapshot["change_counter"]
            or self.dataset_index.history_generation != verification_snapshot["generation"]
        ):
            return VerificationResult(
                VerificationStatus.ERROR,
                "The dataset changed before a stable verification snapshot could be established.",
                condition=condition_mapping,
                provenance=[{"query": query, "condition": condition_mapping, "dataset_version": verification_snapshot["version"]}],
            )

        try:
            located = self.query_locator.locate(
                query,
                max_candidates=max_candidates,
                retrieval_mode="verification",
                evidence_requirements={"condition": condition_mapping},
            )
        except Exception as exc:
            return VerificationResult(
                VerificationStatus.ERROR,
                f"Evidence retrieval failed: {exc}",
                condition=condition_mapping,
                provenance=[{"query": query, "condition": condition_mapping}],
            )
        if (
            not isinstance(located, Mapping)
            or not isinstance(located.get("candidates"), list)
            or not isinstance(located.get("unknown_tokens", []), list)
        ):
            return VerificationResult(
                VerificationStatus.ERROR,
                "Evidence retrieval returned a malformed result.",
                condition=condition_mapping,
            )
        candidates = located.get("candidates", [])
        unknown_tokens = located.get("unknown_tokens", [])
        if any(not hasattr(candidate, "record_id") for candidate in candidates):
            return VerificationResult(
                VerificationStatus.ERROR,
                "Evidence retrieval returned a malformed candidate.",
                condition=condition_mapping,
            )
        candidate_ids = {candidate.record_id for candidate in candidates}
        dataset_record_ids = set(verification_snapshot["records"])
        coverage = {
            "dataset_id": verification_snapshot["dataset_id"],
            "dataset_version": verification_snapshot["version"],
            "dataset_generation": verification_snapshot["generation"],
            "dataset_record_count": len(dataset_record_ids),
            "candidate_record_count": len(candidate_ids),
            "scope": normalized_condition.scope or "all dataset records",
            "required_predicates": [normalized_condition.predicate],
            "retrieval_exhaustive": bool(located.get("retrieval_exhaustive", False)),
            "truncated": bool(located.get("truncated", False)),
            "supporting_evidence": [],
            "contradicting_evidence": [],
            "unassessed_conditions": [],
            "missing_or_malformed_fields": [],
            "conflicting_sources": None,
            "conflict_assessment": "Cross-source conflicts and source authority are not independently assessed.",
            "assumptions": [
                "All dataset records are treated as the claim scope unless an explicit scope is implemented."
            ],
        }
        if located.get("truncated") and located.get("retrieval_mode") == "verification":
            return VerificationResult(
                VerificationStatus.INCONCLUSIVE,
                "Verification retrieval was truncated before the required evidence set was established.",
                candidates=[candidate.__dict__ for candidate in candidates],
                unknown_tokens=unknown_tokens,
                condition=condition_mapping,
                provenance=[{"query": query, "condition": condition_mapping, "retrieval": located}],
                evidence_coverage=coverage,
            )
        scope_covered = candidate_ids == dataset_record_ids
        if not scope_covered:
            coverage["unassessed_conditions"] = [
                "The lexical retrieval set does not cover every record in the dataset."
            ]
        if not candidates:
            if unknown_tokens:
                return VerificationResult(
                    VerificationStatus.INCONCLUSIVE,
                    "No indexed evidence matched the query; unsupported tokens were identified.",
                    candidates=[],
                    unknown_tokens=unknown_tokens,
                    condition=condition_mapping,
                    provenance=[{"query": query, "unknown_tokens": unknown_tokens, "condition": condition_mapping}],
                    evidence_coverage=coverage,
                )
            return VerificationResult(
                VerificationStatus.INCONCLUSIVE,
                "No indexed evidence matched the query.",
                candidates=[],
                unknown_tokens=unknown_tokens,
                condition=condition_mapping,
                provenance=[{"query": query, "condition": condition_mapping}],
                evidence_coverage=coverage,
            )

        evidence_records = []
        for candidate in candidates:
            record = verification_snapshot["records"].get(candidate.record_id)
            if record is None:
                continue
            evidence_records.append({
                "record_id": record.record_id,
                "source_location": record.source_location,
                "content": record.content,
                "metadata": record.metadata,
                "dataset_id": dataset_store.dataset_id,
            })

        required_evidence_met = (
            normalized_condition.required_evidence is None
            or len(evidence_records) >= normalized_condition.required_evidence
        )
        if not required_evidence_met:
            coverage["unassessed_conditions"].append(
                "The explicit required_evidence threshold was not met."
            )

        query_years = self._query_years(query)
        ordering_field = normalized_condition.ordering
        if ordering_field is None and len(query_years) >= 2:
            ordering_field = normalized_condition.year_field
        condition_type = str(normalized_condition.predicate or "").lower()
        is_sequence = condition_type in {
            "increase", "increasing", "increasing_sequence", "strictly_increasing",
            "decrease", "decreasing", "decreasing_sequence", "strictly_decreasing",
        }
        if is_sequence and ordering_field is None:
            coverage["unassessed_conditions"].append(
                "A sequence ordering field was not declared or established by an explicit year range."
            )
            return VerificationResult(
                VerificationStatus.INCONCLUSIVE,
                "The sequence condition has no explicit, validated ordering field.",
                candidates=[candidate.__dict__ for candidate in candidates],
                evidence=evidence_records,
                unknown_tokens=unknown_tokens,
                condition=condition_mapping,
                evidence_coverage=coverage,
            )
        adapter_condition = dict(condition_mapping)
        if ordering_field is not None:
            adapter_condition["ordering"] = ordering_field
        try:
            adapter_result = self.evidence_adapter.build_solver_input(
                query,
                adapter_condition,
                candidates,
                evidence_records,
            )
        except Exception as exc:
            return VerificationResult(
                VerificationStatus.ERROR,
                f"Evidence normalization failed: {exc}",
                candidates=[candidate.__dict__ for candidate in candidates],
                evidence=evidence_records,
                unknown_tokens=unknown_tokens,
                condition=condition_mapping,
                provenance=[{"query": query, "condition": condition_mapping}],
                evidence_coverage=coverage,
            )
        if (
            not hasattr(adapter_result, "domains")
            or not hasattr(adapter_result, "constraints")
            or not isinstance(getattr(adapter_result, "unresolved", None), list)
            or not isinstance(getattr(adapter_result, "evidence", None), list)
            or not isinstance(getattr(adapter_result, "unsupported", None), bool)
        ):
            return VerificationResult(
                VerificationStatus.ERROR,
                "Evidence adapter returned a malformed result.",
                candidates=[candidate.__dict__ for candidate in candidates],
                evidence=evidence_records,
                condition=condition_mapping,
                evidence_coverage=coverage,
            )
        if not self.dataset_index._snapshot_is_current(dataset_store, verification_snapshot):
            return VerificationResult(
                VerificationStatus.ERROR,
                "The dataset changed during verification; the result was not evaluated against a stable snapshot.",
                candidates=[candidate.__dict__ for candidate in candidates],
                evidence=adapter_result.evidence,
                condition=condition_mapping,
                evidence_coverage=coverage,
            )
        if adapter_result.unsupported:
            return VerificationResult(
                VerificationStatus.UNSUPPORTED,
                "The verification condition is not supported by the current constraint adapter.",
                candidates=[candidate.__dict__ for candidate in candidates],
                evidence=adapter_result.evidence,
                unknown_tokens=unknown_tokens,
                condition=condition_mapping,
                provenance=[{"query": query, "condition": condition_mapping}],
                evidence_coverage=coverage,
            )
        if adapter_result.unresolved:
            coverage["missing_or_malformed_fields"] = list(adapter_result.unresolved)
        if adapter_result.unresolved:
            return VerificationResult(
                VerificationStatus.INCONCLUSIVE,
                "The query evidence is incomplete or does not match the requested verification condition.",
                candidates=[candidate.__dict__ for candidate in candidates],
                evidence=adapter_result.evidence,
                unknown_tokens=unknown_tokens,
                condition=condition_mapping,
                provenance=[{"query": query, "condition": condition_mapping}],
                evidence_coverage=coverage,
            )

        if is_sequence and ordering_field is not None:
            order_values = [
                self.evidence_adapter._field_value(record, ordering_field)
                for record in evidence_records
            ]
            normalized_order_values = [
                self.evidence_adapter.ordering_identity(value)
                for value in order_values
            ]
            if len(normalized_order_values) != len(set(normalized_order_values)):
                coverage["unassessed_conditions"].append(
                    f"Ordering field {ordering_field!r} has duplicate values."
                )
                return VerificationResult(
                    VerificationStatus.INCONCLUSIVE,
                    "The sequence order is ambiguous because multiple records share an ordering value.",
                    candidates=[candidate.__dict__ for candidate in candidates],
                    evidence=adapter_result.evidence,
                    unknown_tokens=unknown_tokens,
                    condition=condition_mapping,
                    evidence_coverage=coverage,
                )

        years = query_years
        if len(years) >= 2:
            start_year, end_year = min(years), max(years)
            available_years = set()
            invalid_years = []
            for evidence in evidence_records:
                content = evidence.get("content")
                if isinstance(content, dict):
                    year_value = content.get("year")
                    if year_value is not None:
                        try:
                            available_years.add(int(year_value))
                        except (TypeError, ValueError):
                            invalid_years.append(evidence["record_id"])
            missing_years = [year for year in range(start_year, end_year + 1) if year not in available_years]
            if missing_years or invalid_years:
                coverage["unassessed_conditions"] = [
                    "The requested temporal scope has missing or malformed year values."
                ]
                return VerificationResult(
                    VerificationStatus.INCONCLUSIVE,
                    f"The query specifies a year range but evidence is incomplete: missing years {missing_years}; invalid records {invalid_years}.",
                    candidates=[candidate.__dict__ for candidate in candidates],
                    evidence=adapter_result.evidence,
                    unknown_tokens=unknown_tokens,
                    provenance=[{"query": query, "condition": condition_mapping, "missing_years": missing_years}],
                    evidence_coverage=coverage,
                )
            if len(available_years) != len(evidence_records):
                coverage["unassessed_conditions"] = [
                    "Multiple records share a year, so one value per year is not established."
                ]
                return VerificationResult(
                    VerificationStatus.INCONCLUSIVE,
                    "The requested annual sequence is ambiguous because multiple records share a year.",
                    candidates=[candidate.__dict__ for candidate in candidates],
                    evidence=adapter_result.evidence,
                    unknown_tokens=unknown_tokens,
                    condition=condition_mapping,
                    evidence_coverage=coverage,
                )

        try:
            solver = ConstraintSolver(adapter_result.domains, adapter_result.constraints)
            satisfiable = solver.decision()
        except Exception as exc:
            return VerificationResult(
                VerificationStatus.ERROR,
                f"Constraint solver execution failed: {exc}",
                candidates=[candidate.__dict__ for candidate in candidates],
                evidence=adapter_result.evidence,
                unknown_tokens=unknown_tokens,
                condition=condition_mapping,
                solver_outcome="ERROR",
                evidence_coverage=coverage,
            )
        if not self.dataset_index._snapshot_is_current(dataset_store, verification_snapshot):
            return VerificationResult(
                VerificationStatus.ERROR,
                "The dataset changed during solver execution; the result was not evaluated against a stable snapshot.",
                candidates=[candidate.__dict__ for candidate in candidates],
                evidence=adapter_result.evidence,
                condition=condition_mapping,
                solver_outcome="SATISFIABLE" if satisfiable else "UNSATISFIABLE",
                evidence_coverage=coverage,
            )
        solver_outcome = "SATISFIABLE" if satisfiable else "UNSATISFIABLE"
        sufficient_evidence = scope_covered and required_evidence_met and coverage["retrieval_exhaustive"]
        if not sufficient_evidence:
            status = VerificationStatus.INCONCLUSIVE
            rationale = (
                "The formal model is satisfiable, but the available evidence does not establish the original claim."
                if satisfiable
                else "The formal model is unsatisfiable, but the available evidence is insufficient to refute the original claim."
            )
        else:
            status = VerificationStatus.VERIFIED if satisfiable else VerificationStatus.REFUTED
            rationale = (
                "Complete dataset evidence satisfies the declared numeric sequence condition."
                if satisfiable
                else "Complete dataset evidence produces an unsatisfiable sequence and directly contradicts the declared condition."
            )
        coverage["solver_outcome"] = solver_outcome
        coverage["final_status"] = status.value
        coverage["rationale"] = rationale
        evidence_references = [
            {"record_id": item.get("record_id"), "source_location": item.get("source_location")}
            for item in evidence_records
        ]
        if status == VerificationStatus.VERIFIED:
            coverage["supporting_evidence"] = evidence_references
        elif status == VerificationStatus.REFUTED:
            coverage["contradicting_evidence"] = evidence_references
        else:
            coverage["model_consistent_evidence" if satisfiable else "model_conflicting_evidence"] = evidence_references
        result = VerificationResult(
            status=status,
            message=rationale,
            candidates=[candidate.__dict__ for candidate in candidates],
            evidence=adapter_result.evidence,
            solver_result={"satisfiable": satisfiable, "outcome": solver_outcome, "domains": solver.domains, "constraint_count": len(adapter_result.constraints)},
            unknown_tokens=unknown_tokens,
            condition=condition_mapping,
            provenance=[{"query": query, "condition": condition_mapping, "dataset_id": dataset_store.dataset_id, "dataset_version": verification_snapshot["version"]}],
            solver_outcome=solver_outcome,
            evidence_coverage=coverage,
        )
        return result

    def verify(self, *args, **kwargs):
        return self.verify_query(*args, **kwargs)


def build_verification_engine(dictionary_reference: DictionaryReference | None = None) -> VerificationEngine:
    return VerificationEngine(dictionary_reference=dictionary_reference)
