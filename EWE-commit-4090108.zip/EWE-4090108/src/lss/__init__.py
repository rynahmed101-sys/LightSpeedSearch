from .core import Digraph, bfs_distance, bidirectional_distance, solve, solve_bounded_sat, solve_subset_sum
from .search_engine import LocalSearchEngine, search_documents

try:
    from ewe_lss_bridge import DictionaryFirstSearch, HistoricalSearchAdapter
except ImportError:  # pragma: no cover - optional backend bridge
    DictionaryFirstSearch = None  # type: ignore[assignment]
    HistoricalSearchAdapter = None  # type: ignore[assignment]

__all__ = [
    "Digraph",
    "bfs_distance",
    "bidirectional_distance",
    "solve",
    "solve_bounded_sat",
    "solve_subset_sum",
    "LocalSearchEngine",
    "search_documents",
    "DictionaryFirstSearch",
    "HistoricalSearchAdapter",
]

__version__ = "3.5.0"
