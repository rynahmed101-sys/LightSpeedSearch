from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from .core import VERSION, NAME, export_research_package, run_experiment, run_sat_experiment, solve, validate_research_package
from .search_engine import LocalSearchEngine


def _print_status() -> None:
    payload = {
        "name": NAME,
        "version": VERSION,
        "project": "IRDL / Light Speed Search",
        "status": "initialized",
        "provenance": "Historical handoff imported from irdl_handoff_v3.4 and preserved as archive-backed source of truth.",
    }
    print(json.dumps(payload, indent=2, sort_keys=True))


def _parse_edges(raw: list[str]) -> list[tuple[int, int]]:
    edges = []
    for item in raw:
        if not item:
            continue
        left, right = item.split(",", 1)
        edges.append((int(left), int(right)))
    return edges


def _parse_queries(raw: list[str]) -> list[tuple[int, int]]:
    queries = []
    for item in raw:
        if not item:
            continue
        left, right = item.split(",", 1)
        queries.append((int(left), int(right)))
    return queries


def _parse_sat_clauses(raw: list[str]) -> list[list[int]]:
    clauses = []
    for item in raw:
        if not item:
            continue
        clause = [int(part) for part in item.split(",") if part.strip()]
        clauses.append(clause)
    return clauses


def _run_search(args: argparse.Namespace) -> int:
    if args.kind == "reachability":
        problem = {"kind": "reachability", "n": int(args.n), "edges": _parse_edges(args.edges), "queries": _parse_queries(args.queries)}
        result = solve(problem)
    elif args.kind == "subset_sum":
        if not args.weights or not args.targets:
            raise ValueError("--weights and --targets are required for subset_sum")
        weights = [int(x) for x in args.weights.split(",")]
        targets = [int(x) for x in args.targets.split(",")]
        result = solve({"kind": "subset_sum", "weights": weights, "targets": targets})
    elif args.kind == "sat":
        if not args.clauses:
            raise ValueError("--clauses are required for sat")
        result = solve({"kind": "sat", "variables": int(args.variables), "clauses": _parse_sat_clauses(args.clauses)})
    else:
        raise ValueError(f"Unsupported search kind: {args.kind}")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


def _run_experiment(args: argparse.Namespace) -> int:
    if args.kind == "reachability":
        result = run_experiment()
    elif args.kind == "subset_sum":
        result = solve({"kind": "subset_sum", "weights": [3, 5, 9, 11], "targets": [8, 14, 100]})
    elif args.kind == "sat":
        result = run_sat_experiment()
    else:
        raise ValueError(f"Unsupported kind: {args.kind}")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


def _run_validate() -> int:
    subprocess.run([sys.executable, "-m", "pytest", "-q"], check=True)
    return 0


def _run_report() -> int:
    print(json.dumps({"name": NAME, "version": VERSION, "status": "report-ready", "summary": "Reachability and subset-sum baselines are preserved; export package can be generated."}, indent=2, sort_keys=True))
    return 0


def _run_export(args: argparse.Namespace) -> int:
    result = export_research_package(version=args.version)
    print(json.dumps({"export": result}, indent=2, sort_keys=True))
    return 0


def _run_engine(args: argparse.Namespace) -> int:
    root = Path(__file__).resolve().parents[2]
    index_dir = Path(args.index_dir) if args.index_dir else root / "docs"
    engine = LocalSearchEngine()
    indexed = engine.index_directory(index_dir)
    if args.query:
        results = engine.search(args.query, limit=args.limit)
        payload = {"query": args.query, "count": len(results), "results": results}
    else:
        payload = {"indexed_documents": len(indexed), "documents": indexed}
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="IRDL / Light Speed Search research workbench")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    status_parser = subparsers.add_parser("status", help="show basic tool status")
    status_parser.set_defaults(func=lambda _args: _print_status())

    search_parser = subparsers.add_parser("search", help="run a search request")
    search_parser.add_argument("--kind", choices=["reachability", "subset_sum", "sat"], required=True)
    search_parser.add_argument("--n", type=int, default=5)
    search_parser.add_argument("--edges", nargs="*", default=[])
    search_parser.add_argument("--queries", nargs="*", default=[])
    search_parser.add_argument("--weights")
    search_parser.add_argument("--targets")
    search_parser.add_argument("--variables", type=int, default=4)
    search_parser.add_argument("--clauses", nargs="*", default=[])
    search_parser.set_defaults(func=_run_search)

    experiment_parser = subparsers.add_parser("experiment", help="run an experiment")
    experiment_parser.add_argument("--kind", choices=["reachability", "subset_sum", "sat"], default="reachability")
    experiment_parser.set_defaults(func=_run_experiment)

    validate_parser = subparsers.add_parser("validate", help="run validation tests")
    validate_parser.set_defaults(func=lambda _args: _run_validate())

    report_parser = subparsers.add_parser("report", help="print a concise report")
    report_parser.set_defaults(func=lambda _args: _run_report())

    export_parser = subparsers.add_parser("export", help="create a versioned research handoff archive")
    export_parser.add_argument("--version", default=VERSION)
    export_parser.set_defaults(func=_run_export)

    engine_parser = subparsers.add_parser("engine", help="index local documentation and run a local text search")
    engine_parser.add_argument("--index-dir", default=str(Path(__file__).resolve().parents[2] / "docs"))
    engine_parser.add_argument("--query", default="")
    engine_parser.add_argument("--limit", type=int, default=5)
    engine_parser.set_defaults(func=_run_engine)

    args = parser.parse_args(argv)
    try:
        result = args.func(args)
        if result is not None:
            raise SystemExit(int(result))
        raise SystemExit(0)
    except SystemExit:
        raise
    except Exception as exc:  # pragma: no cover
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    raise SystemExit(main())
