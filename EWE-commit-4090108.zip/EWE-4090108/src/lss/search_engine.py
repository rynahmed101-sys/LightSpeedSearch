from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Iterable, Sequence

_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+(?:'[A-Za-z0-9_]+)?")


class LocalSearchEngine:
    """A lightweight local text index for documentation and research notes."""

    def __init__(self) -> None:
        self.documents: list[dict] = []
        self._document_by_id: dict[str, dict] = {}
        self._term_index: dict[str, Counter[str]] = {}
        self._doc_frequency: dict[str, int] = {}
        self._query_cache: dict[str, list[dict]] = {}

    def _coerce_document(self, raw: object) -> dict:
        if isinstance(raw, dict):
            doc_id = str(raw.get("id") or raw.get("name") or raw.get("path") or len(self._document_by_id))
            title = str(raw.get("title") or raw.get("name") or "")
            content = str(raw.get("content") or raw.get("text") or "")
            return {"id": doc_id, "title": title, "content": content}
        if isinstance(raw, tuple) and len(raw) >= 3:
            doc_id, title, content = raw[:3]
            return {"id": str(doc_id), "title": str(title), "content": str(content)}
        if hasattr(raw, "id") or hasattr(raw, "title") or hasattr(raw, "content"):
            doc_id = getattr(raw, "id", getattr(raw, "name", None))
            title = getattr(raw, "title", getattr(raw, "name", ""))
            content = getattr(raw, "content", getattr(raw, "text", ""))
            return {"id": str(doc_id if doc_id is not None else len(self._document_by_id)), "title": str(title), "content": str(content)}
        text = str(raw)
        return {"id": str(len(self._document_by_id)), "title": "Document", "content": text}

    def index_documents(self, documents: Iterable[object]) -> list[str]:
        self.documents = []
        self._document_by_id = {}
        self._term_index = {}
        self._doc_frequency = {}
        self._query_cache.clear()

        for raw in documents:
            doc = self._coerce_document(raw)
            doc_id = doc["id"]
            if not doc["title"] and not doc["content"]:
                continue
            self.documents.append(doc)
            self._document_by_id[doc_id] = doc

        for doc in self.documents:
            doc_id = doc["id"]
            text = f"{doc.get('title', '')} {doc.get('content', '')}".strip()
            tokens = _tokenize(text)
            counts = Counter(tokens)
            for token, count in counts.items():
                self._term_index.setdefault(token, Counter())[doc_id] = count
            self._doc_frequency[doc_id] = len(counts)

        for token, counts in self._term_index.items():
            self._doc_frequency[token] = len(counts)

        return [doc["id"] for doc in self.documents]

    def index_directory(self, directory: str | Path) -> list[str]:
        base = Path(directory)
        if not base.exists():
            raise FileNotFoundError(f"Search index directory not found: {directory}")

        docs: list[dict] = []
        for path in sorted(base.rglob("*")):
            if not path.is_file():
                continue
            if path.suffix.lower() not in {".md", ".txt", ".rst", ".json", ".csv"}:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if path.suffix.lower() == ".json":
                try:
                    payload = json.loads(text)
                except json.JSONDecodeError:
                    payload = None
                if isinstance(payload, list):
                    for item in payload:
                        if isinstance(item, dict):
                            docs.append({
                                "id": str(item.get("id") or item.get("name") or path.name),
                                "title": str(item.get("title") or item.get("name") or path.stem),
                                "content": str(item.get("content") or item.get("text") or json.dumps(item, sort_keys=True)),
                            })
                    continue
                if isinstance(payload, dict):
                    docs.append({
                        "id": str(payload.get("id") or payload.get("name") or path.stem),
                        "title": str(payload.get("title") or payload.get("name") or path.stem),
                        "content": str(payload.get("content") or payload.get("text") or json.dumps(payload, sort_keys=True)),
                    })
                    continue
            docs.append({
                "id": str(path.relative_to(base)),
                "title": path.stem.replace("_", " ").replace("-", " ").title(),
                "content": text,
            })
        return self.index_documents(docs)

    def search(self, query: str, limit: int = 5) -> list[dict]:
        if not query or not self.documents:
            return []

        key = f"{query}:{limit}"
        if key in self._query_cache:
            return self._query_cache[key]

        query_terms = _tokenize(query)
        if not query_terms:
            return []

        total_docs = max(1, len(self.documents))
        scored: list[dict] = []
        for doc in self.documents:
            doc_id = doc["id"]
            counts = Counter()
            for token, counter in self._term_index.items():
                if doc_id in counter:
                    counts[token] = counter[doc_id]
            title_tokens = _tokenize(doc.get("title", ""))
            title_set = set(title_tokens)
            score = 0.0
            for term in set(query_terms):
                df = self._doc_frequency.get(term, 0)
                if not df:
                    continue
                term_count = counts.get(term, 0)
                if not term_count:
                    continue
                idf = math.log((1 + total_docs) / (1 + df)) + 1.0
                score += term_count * idf
                if term in title_set:
                    score += 2.0 * idf
            if score > 0.0:
                scored.append({
                    "id": doc_id,
                    "title": doc.get("title", "Document"),
                    "content": doc.get("content", ""),
                    "score": round(score, 6),
                })

        scored.sort(key=lambda item: item["score"], reverse=True)
        results = scored[:limit]
        self._query_cache[key] = results
        return results


def _tokenize(text: str | Sequence[str]) -> list[str]:
    if isinstance(text, str):
        return [match.lower() for match in _TOKEN_RE.findall(text)]
    words: list[str] = []
    for part in text:
        words.extend(_tokenize(str(part)))
    return words


def search_documents(documents: Iterable[object], query: str, limit: int = 5) -> list[dict]:
    engine = LocalSearchEngine()
    engine.index_documents(documents)
    return engine.search(query, limit=limit)
