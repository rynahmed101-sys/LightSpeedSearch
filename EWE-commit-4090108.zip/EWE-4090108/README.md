# EWE: Encoding, Retrieval, and Evidence-Aware Verification

This project combines a spelling-identity encoding, a versioned dictionary, an
in-memory dataset store, an incremental lexical index, retrieval, and a
finite-domain constraint solver. Lexical relevance and solver satisfiability
are not independently proof of a real-world claim.

## Integrated workspace and package layout

This workspace keeps the EWE modules at the repository root and installs the Light Speed Search (LSS) package from the `src/lss` package directory. The historical Search the Past reference is also preserved in the extracted `search-the-past-master/` directory for local inspection and integration work.

## Actual audit summary

The available artifacts were inspected before integration:

- EWE: the root-level Python modules (`dictionary_reference.py`, `dataset_store.py`, `dataset_index.py`, `query_locator.py`, `verification_engine.py`, `evidence_adapter.py`, `constraint_information.py`, and the v2.2 encoding module) remain the deterministic dictionary and indexing core.
- LSS: the extracted package under `src/lss` includes the reusable local text index and document search primitives, along with the reachability/subset-sum computational library. It is preserved as the retrieval/computation layer rather than rewritten.
- Lexical data: the WordNet archive `wn3.1.dict.tar.gz` contains the Princeton WordNet 3.1 dictionary files, including the `dict/` index and data files, and its licensing text is preserved in the packaged files.
- Historical search: `search-the-past-master/past-search.html` contains the browser widget logic for DuckDuckGo, Google, and Bing time-bounded searches; the equivalent Python adapter is implemented in `ewe_lss_bridge.py`.

The integrated behavior is intentionally dictionary-first: EWE provides the normalized spelling identity and lexical lookups, while LSS provides local document indexing, ranking, and computational search support. The bridge module keeps discovery separate from verification and exposes source URLs, provider metadata, and a clear dictionary-first retrieval path.

## Modules and quick start

- `english_word_encoding_v22.py` normalizes and encodes ASCII spellings.
- `dictionary_reference.py` manages supported spellings and their stable IDs.
- `dataset_store.py` stores records and journals mutations.
- `dataset_index.py` maintains word/sequence postings, frequencies, and temporal
  record values.
- `query_locator.py` retrieves lexical candidates and reports truncation.
- `evidence_adapter.py` validates and orders numeric evidence.
- `verification_engine.py` checks evidence coverage before interpreting solver
  results.
- `constraint_information.py` provides a finite-domain solver adapter.

```python
from dataset_store import DatasetStore
from dictionary_reference import DictionaryReference
from verification_engine import VerificationEngine

dictionary = DictionaryReference(
    source="demo",
    version="v1",
    words=["revenue", "year", "growth"],
)
dataset = DatasetStore("demo")
dataset.add_record("2021", {"year": 2021, "revenue": 100})
dataset.add_record("2022", {"year": 2022, "revenue": 120})

engine = VerificationEngine(dictionary_reference=dictionary)
result = engine.verify_query(
    dataset,
    "revenue year",
    {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"},
)
print(result.status, result.solver_outcome, result.evidence_coverage)
```

```python
from dataset_store import DatasetStore
from dictionary_reference import DictionaryReference
from ewe_lss_bridge import DictionaryFirstSearch, HistoricalSearchAdapter

words = ["revenue", "growth", "market", "north", "south"]
dictionary = DictionaryReference(source="demo", version="v1", words=words)
dataset = DatasetStore("bridge-demo")
dataset.add_record("r1", {"text": "revenue growth north"})

search = DictionaryFirstSearch(dictionary, dataset)
print(search.discover([
    {"id": "doc-a", "title": "Revenue report", "content": "Revenue growth in north markets."},
], "revenue growth", limit_results=1, max_candidates=5))
print(HistoricalSearchAdapter().build_url("google", "revenue growth", 2020, 2022))
```

## Encoding and normalization

Spellings are trimmed, lowercased, and restricted to nonempty ASCII letters.
The base-27 identity encoding is reversible and case-insensitive (`CAT` and
`cat` have the same ID). It is a spelling identity, not a semantic or
similarity measure. Unsupported dictionary tokens are omitted from lexical
postings; a query with no supported token cannot establish a negative claim.

## Dataset changes and index synchronization

The store is in-memory. Its initial version is `dataset-v0`; every supported
mutation advances a monotonically increasing `change_id` and version. Each
journal entry carries the store generation, action, record ID, and resulting
version. `add_record` is an upsert for compatibility, `update_record` inserts
when the ID is absent, and deleting a missing ID is a journalled no-op.
Duplicate IDs therefore resolve to one current record; they do not create
multiple index entries.

The index initialization state is explicit: `uninitialized`,
`synchronized`, `inconsistent`, or `behind_dataset`. The checkpoint means that
all changes through that ID have been committed to the index. An empty index
is not treated as initialized merely because the change log is empty.

Synchronization takes an isolated dataset snapshot. It validates event IDs,
order, actions, versions, generation, and retention boundary against the
checkpoint. A missing, cleared, malformed, or replaced history causes a full
rebuild from the snapshot; an uninitialized index also rebuilds, including for
a genuinely empty dataset. A valid contiguous suffix is applied incrementally.
Index changes are staged on a private copy and committed together with the
checkpoint. If mutation fails, the checkpoint is not advanced; retry either
replays the journal or rebuilds from a fresh snapshot. If the dataset changes
during a rebuild/sync, synchronization retries once and then raises an
explicit error rather than claiming success.

`DatasetStore.clear_change_history()` records the retention boundary. Clearing
the public `change_log` list directly is detectable as a gap when the index
needs those events. History before an index's checkpoint may be discarded
without invalidating that already-applied checkpoint; history needed after the
checkpoint cannot be assumed complete. The dataset and index are process-local
and are not crash-durable.

Synchronization results include `mode` (`rebuild`, `incremental`, or `noop`),
the recovery reason/history issue, records synchronized, and checkpoint.
`DatasetIndex.full_rebuild_count`, `incremental_sync_count`, and
`noop_sync_count` expose counters for validation and instrumentation.

## Index statistics and temporal periods

Text is extracted from a string, a mapping's `text` field, or the mapping's
rendered keys and values, then tokenized as lowercase ASCII letter runs.
Collection frequency is the total indexed word occurrences; document
frequency is the number of records containing a word; per-record term
frequency is held separately in `record_term_frequency`. The retained
`word_statistics.term_frequency` field is a legacy corpus-total alias for
collection frequency. These word counts are not numeric business metrics.

Temporal frequency counts indexed word occurrences by a record's selected
`year`, `date`, `timestamp`, `time`, or `period` field. Periods require explicit
start and end boundaries and use inclusive comparisons to preserve the
existing API contract. Equal boundaries select that exact value. Numeric
values, dates, and ISO timestamps are accepted; unlike types and naive/aware
timezone combinations are not silently compared. Missing or malformed record
timestamps are excluded and reported in coverage warnings. A zero baseline
has an undefined relative change (`None`), not an invented percentage.

## Retrieval, ordering, and verification

`QueryLocator` returns relevance-ranked lexical/sequence candidates. Its
verification retrieval contract is exhaustive for lexical matches unless a
candidate limit is reached; it does not prove that nonmatching records are
irrelevant to a claim. A truncated result is `INCONCLUSIVE`, and no-match
retrieval is also not proof of absence. The current verification engine
conservatively requires the lexical candidate set to cover the dataset's
declared scope before returning a truth-like status. Queries requiring a
different scope need explicit scope support, which is not currently
implemented.

Ordering supports homogeneous finite numbers, dates/ISO timestamps, or
strings. Nested mapping paths use dot notation. Missing sort values are ordered
last in the sorting helper but are unresolved for verification; mixed
supported types and mixing timezone-aware with naive dates fail explicitly.
Ties are deterministic by record ID, then input order. Ascending is the
default; `sort_direction="descending"` or `descending=True` requests reverse
value order while keeping deterministic ties.

The solver reports satisfiability of the constructed finite model only. The
engine keeps that outcome separate from the final status and applies evidence
coverage checks:

- `VERIFIED`: all retrieved records cover the supported scope and the numeric
  sequence condition is satisfied.
- `REFUTED`: complete supported evidence directly contradicts that condition.
- `INCONCLUSIVE`: evidence is absent, truncated, malformed, incomplete,
  conflicting, or otherwise insufficient. A satisfiable model may still be
  inconclusive.
- `UNSUPPORTED`: the requested predicate is outside the implemented adapter.
- `ERROR`: synchronization, retrieval, normalization, or solver execution
  failed or the dataset changed during verification.

Only increasing/decreasing numeric sequence predicates are implemented.
Interpretation of natural-language quantifiers, source authority, multi-entity
scope, general existential/universal/negative claims, and semantic matching
remain unsupported. Solver unsatisfiability is used as refutation only when the
engine has complete numeric evidence for this supported sequence predicate.

## Benchmarks and tests

Run the benchmark and test suite from the repository root:

```sh
python3 benchmark_lookup.py
python3 -m unittest -q
```

The benchmark uses fixed-seed synthetic data, warmups, repeated measurements,
medians and interquartile ranges. It reports index construction separately
from full-scan, indexed, and frequency-aware query latency; equivalent query
result sets are checked. Mutation latency reuses an already-built index, and
rebuild-after-mutations is measured separately. Temporal comparison and
verification end-to-end/retrieval/solver timings are also reported. Results
are workload- and machine-specific; there are no claimed speedup thresholds.

## Known limitations

- Dataset and index storage are in-memory and not durable across process exit.
- To make a batch failure-atomic, synchronization stages a full in-memory index
  copy before commit. This favors correctness over mutation latency; for larger
  indexes, a one-record update may cost more than a rebuild.
- Supported verification is intentionally narrow and requires coverage of the
  full dataset scope; there is no general claim parser or configurable scope
  resolver.
- Lexical matching and the dictionary do not establish semantic relevance,
  source authority, or evidence independence.
- Direct mutation of record contents or journal metadata bypasses the store's
  version/change APIs and is unsupported.
- `data/esdb-60-A-1.txt` has its own preserved licensing/provenance notes in
  `AUDIT_NOTES.md` and the associated `data/` files.
