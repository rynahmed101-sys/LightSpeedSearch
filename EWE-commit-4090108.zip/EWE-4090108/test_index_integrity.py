from __future__ import annotations

import random
import unittest
from unittest.mock import Mock, patch

from benchmark_lookup import benchmark
from dataset_index import DatasetIndex
from dataset_store import DatasetStore
from dictionary_reference import DictionaryReference
from evidence_adapter import EvidenceAdapter
from query_locator import QueryLocator


def make_dictionary() -> DictionaryReference:
    return DictionaryReference(
        words=["revenue", "year", "growth", "market", "north", "south", "noise"]
    )


def index_state(index: DatasetIndex) -> dict[str, object]:
    return {
        "record_text": dict(index.record_text),
        "record_locations": dict(index.record_locations),
        "record_time_values": dict(index.record_time_values),
        "record_word_counts": {key: dict(value) for key, value in index.record_word_counts.items()},
        "record_term_frequency": {key: dict(value) for key, value in index.record_term_frequency.items()},
        "word_record_sets": {key: set(value) for key, value in index.word_record_sets.items()},
        "word_statistics": {key: dict(value) for key, value in index.word_statistics.items()},
        "word_occurrences": {
            key: sorted(
                (item.record_id, item.word, item.position, item.source_location)
                for item in values
            )
            for key, values in index.word_occurrences.items()
        },
        "sequence_occurrences": {
            key: sorted(
                (item.record_id, item.sequence, item.positions, item.source_location)
                for item in values
            )
            for key, values in index.sequence_occurrences.items()
        },
        "document_count": index.document_count,
    }


class IndexIntegrityTests(unittest.TestCase):
    def test_missing_history_rebuilds_nonempty_dataset_and_empty_dataset_initializes(self):
        dictionary = make_dictionary()
        dataset = DatasetStore("missing-history")
        dataset.add_record("present", {"text": "revenue growth"})
        dataset.change_log.clear()
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)

        result = dataset.sync_index(index)

        self.assertTrue(result["synchronized"])
        self.assertTrue(result["rebuilt"])
        self.assertIn("present", {item.record_id for item in index.lookup_word("revenue")})
        self.assertEqual(index.document_count, 1)
        self.assertEqual(result["mode"], "rebuild")
        self.assertIn("change_history_invalid", result["reason"])

        empty = DatasetStore("empty")
        empty_index = DatasetIndex(empty.dataset_id, dictionary_reference=dictionary)
        empty_result = empty.sync_index(empty_index)
        self.assertTrue(empty_result["synchronized"])
        self.assertTrue(empty_result["rebuilt"])
        self.assertEqual(empty_index.document_count, 0)
        self.assertEqual(empty_index.sync_state, "synchronized")

    def test_missing_history_after_a_checkpoint_rebuilds_instead_of_advancing_incrementally(self):
        dataset = DatasetStore("history-cleared-after-init")
        dictionary = make_dictionary()
        dataset.add_record("r1", {"text": "revenue"})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)
        dataset.add_record("r2", {"text": "growth"})
        dataset.clear_change_history()

        result = dataset.sync_index(index)

        self.assertTrue(result["synchronized"])
        self.assertTrue(result["rebuilt"])
        self.assertEqual(index.document_count, 2)
        self.assertEqual(index.last_applied_change_id, dataset.change_counter)
        self.assertIn("change_history_invalid", result["reason"])

    def test_valid_insert_update_delete_are_incremental_without_rebuilding(self):
        dictionary = make_dictionary()
        dataset = DatasetStore("incremental")
        dataset.add_record("r1", {"text": "revenue north", "year": 2021})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)
        rebuild_count = index.full_rebuild_count

        dataset.add_record("r2", {"text": "growth south", "year": 2022})
        with patch.object(index, "_stage_rebuild", side_effect=AssertionError("unexpected rebuild")):
            self.assertEqual(dataset.sync_index(index)["mode"], "incremental")
        self.assertEqual(index.full_rebuild_count, rebuild_count)
        self.assertIs(index.dictionary_reference, dictionary)
        self.assertEqual(len(index.lookup_word("growth")), 1)

        dataset.update_record("r2", {"text": "market north", "year": 2023})
        with patch.object(index, "_stage_rebuild", side_effect=AssertionError("unexpected rebuild")):
            self.assertEqual(dataset.sync_index(index)["mode"], "incremental")
        self.assertEqual(index.lookup_word("growth"), [])
        self.assertEqual(len(index.lookup_word("market")), 1)
        self.assertEqual(index.record_time_values["r2"]["year"], 2023)

        dataset.remove_record("r2")
        with patch.object(index, "_stage_rebuild", side_effect=AssertionError("unexpected rebuild")):
            self.assertEqual(dataset.sync_index(index)["mode"], "incremental")
        self.assertNotIn("r2", index.record_text)
        self.assertEqual(index.full_rebuild_count, rebuild_count)
        snapshot = index_state(index)
        self.assertEqual(dataset.sync_index(index)["mode"], "noop")
        self.assertEqual(index_state(index), snapshot)

    def test_index_full_state_matches_fresh_rebuild_after_randomized_mutations(self):
        seed = 91421
        randomizer = random.Random(seed)
        dictionary = make_dictionary()
        dataset = DatasetStore("random-equivalence")
        for number in range(5):
            dataset.add_record(
                f"r{number}",
                {"text": "revenue growth north", "year": 2020 + number},
                source_location=f"source-{number}",
            )
        incremental = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(incremental)
        operations = []

        for step in range(60):
            current_ids = list(dataset.records)
            action = randomizer.choice(("insert", "update", "delete", "retry"))
            record_id = f"r{randomizer.randrange(12)}"
            operations.append((action, record_id))
            if action == "insert":
                dataset.add_record(
                    record_id,
                    {"text": randomizer.choice(("revenue north", "growth south", "market growth")), "year": 2020 + step},
                    source_location=f"source-{step}",
                )
            elif action == "update" and current_ids:
                record_id = randomizer.choice(current_ids)
                dataset.update_record(
                    record_id,
                    {"text": randomizer.choice(("revenue market", "growth north", "south growth")), "year": 2020 + step},
                    source_location=f"updated-{step}",
                )
            elif action == "delete" and current_ids:
                dataset.remove_record(randomizer.choice(current_ids))
            elif action == "retry":
                dataset.sync_index(incremental)

            dataset.sync_index(incremental)
            expected = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
            expected.rebuild(dataset)
            with self.subTest(seed=seed, step=step, operations=operations):
                self.assertEqual(index_state(incremental), index_state(expected))
                for word in ("revenue", "growth", "market", "north", "south"):
                    self.assertEqual(
                        sorted((item.record_id, item.position) for item in incremental.lookup_word(word)),
                        sorted((item.record_id, item.position) for item in expected.lookup_word(word)),
                    )
                incremental_candidates = QueryLocator(dictionary, incremental).locate(
                    "revenue growth", max_candidates=None
                )["candidates"]
                expected_candidates = QueryLocator(dictionary, expected).locate(
                    "revenue growth", max_candidates=None
                )["candidates"]
                self.assertEqual(
                    [
                        (item.record_id, item.matched_terms, item.positions, item.score)
                        for item in incremental_candidates
                    ],
                    [
                        (item.record_id, item.matched_terms, item.positions, item.score)
                        for item in expected_candidates
                    ],
                )
                for identity, stats in incremental.word_statistics.items():
                    self.assertEqual(
                        stats["document_frequency"],
                        len(incremental.word_record_sets[identity]),
                    )
                    self.assertEqual(
                        stats["collection_frequency"],
                        sum(counts.get(identity, 0) for counts in incremental.record_term_frequency.values()),
                    )
                for record_id, counts in incremental.record_word_counts.items():
                    positions = [
                        item.position
                        for occurrences in incremental.word_occurrences.values()
                        for item in occurrences
                        if item.record_id == record_id
                    ]
                    self.assertEqual(len(positions), sum(counts.values()))
                    self.assertEqual(len(positions), len(set(positions)))
                    tokens = incremental._tokenize_text(incremental.record_text[record_id])
                    self.assertTrue(all(0 <= position < len(tokens) for position in positions))
                for (length, sequence), occurrences in incremental.sequence_occurrences.items():
                    self.assertEqual(length, len(sequence))
                    for occurrence in occurrences:
                        self.assertEqual(len(occurrence.positions), length)
                        self.assertEqual(
                            list(occurrence.positions),
                            list(range(occurrence.positions[0], occurrence.positions[0] + length)),
                        )
                        self.assertLess(occurrence.positions[-1], len(incremental._tokenize_text(incremental.record_text[occurrence.record_id])))
                temporal = incremental.temporal_frequency(
                    "revenue",
                    time_field="year",
                    period={"start": 2020, "end": 2050},
                )
                direct_records = [
                    record for record in dataset.records.values()
                    if 2020 <= record.content["year"] <= 2050
                ]
                direct_frequency = sum(
                    incremental._tokenize_text(record.content["text"]).count("revenue")
                    for record in direct_records
                )
                self.assertEqual(temporal["frequency"], direct_frequency)
                self.assertEqual(temporal["observation_count"], len(direct_records))

    def test_failure_before_mutation_and_during_posting_application_keeps_checkpoint_safe(self):
        dictionary = make_dictionary()
        dataset = DatasetStore("failure-staging")
        dataset.add_record("r1", {"text": "revenue north"})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)
        committed_state = index_state(index)
        checkpoint = index.last_applied_change_id
        dataset.update_record("r1", {"text": "growth south"})
        with patch.object(DatasetIndex, "remove_record", side_effect=RuntimeError("injected before event")):
            with self.assertRaisesRegex(RuntimeError, "injected"):
                dataset.sync_index(index)
        self.assertEqual(index.last_applied_change_id, checkpoint)
        self.assertEqual(index_state(index), committed_state)
        index.sync_state = "synchronized"

        original_add = DatasetIndex.add_record

        def add_then_fail(staged, record, **kwargs):
            result = original_add(staged, record, **kwargs)
            if getattr(record, "record_id", None) == "r1":
                raise RuntimeError("injected after postings and statistics")
            return result

        with patch.object(DatasetIndex, "add_record", add_then_fail):
            with self.assertRaisesRegex(RuntimeError, "after postings"):
                dataset.sync_index(index)
        self.assertEqual(index.last_applied_change_id, checkpoint)
        self.assertEqual(index_state(index), committed_state)

        dataset.sync_index(index)
        self.assertIn("growth", index.record_text["r1"])
        self.assertEqual(index.word_statistics[dictionary.identity_for("growth")]["collection_frequency"], 1)
        self.assertEqual(index.word_statistics[dictionary.identity_for("growth")]["document_frequency"], 1)
        self.assertNotIn(dictionary.identity_for("revenue"), index.word_statistics)

    def test_rebuild_retries_when_dataset_changes_during_snapshot_indexing(self):
        dataset = DatasetStore("mutation-during-rebuild")
        dataset.add_record("r1", {"text": "revenue"})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=make_dictionary())
        original_check = DatasetIndex._snapshot_is_current
        first = True

        def mutate_after_first_build(store, snapshot):
            nonlocal first
            if first:
                first = False
                store.add_record("r2", {"text": "growth"})
            return original_check(store, snapshot)

        with patch.object(DatasetIndex, "_snapshot_is_current", new=staticmethod(mutate_after_first_build)):
            result = dataset.sync_index(index)
        self.assertTrue(result["synchronized"])
        self.assertEqual(index.document_count, 2)
        self.assertEqual(index.last_applied_change_id, dataset.change_counter)

    def test_dataset_mutation_contract_is_upsert_compatible_and_explicit(self):
        dataset = DatasetStore("mutation-contract")
        dataset.add_record("same", {"text": "revenue"})
        dataset.add_record("same", {"text": "growth"})
        self.assertEqual(dataset.get_record("same").content["text"], "growth")
        dataset.update_record("not-yet-present", {"text": "market"})
        self.assertIn("not-yet-present", dataset.records)
        before_delete = dataset.change_counter
        dataset.remove_record("absent")
        self.assertEqual(dataset.change_counter, before_delete + 1)
        dataset.remove_record("same")
        dataset.add_record("same", {"text": "north"})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=make_dictionary())
        dataset.sync_index(index)
        self.assertNotIn("growth", index.record_text["same"])
        self.assertIn("north", index.record_text["same"])

    def test_failure_before_commit_and_after_commit_is_retry_safe(self):
        dictionary = make_dictionary()
        dataset = DatasetStore("failure-commit")
        dataset.add_record("r1", {"text": "revenue"})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)
        initial_checkpoint = index.last_applied_change_id
        dataset.add_record("r2", {"text": "growth"})
        fail_before_commit = Mock(side_effect=RuntimeError("before checkpoint"))
        with patch.object(DatasetIndex, "_snapshot_is_current", new=staticmethod(fail_before_commit)):
            with self.assertRaisesRegex(RuntimeError, "before checkpoint"):
                dataset.sync_index(index)
        self.assertEqual(index.last_applied_change_id, initial_checkpoint)
        dataset.sync_index(index)
        self.assertEqual(index.word_statistics[dictionary.identity_for("growth")]["collection_frequency"], 1)

        dataset.add_record("r3", {"text": "growth"})
        original_commit = DatasetIndex._commit_staged_index
        calls = 0

        def commit_then_fail(receiver, staged):
            nonlocal calls
            original_commit(receiver, staged)
            calls += 1
            if calls == 1:
                raise RuntimeError("after index commit")

        with patch.object(DatasetIndex, "_commit_staged_index", commit_then_fail):
            with self.assertRaisesRegex(RuntimeError, "after index commit"):
                dataset.sync_index(index)
        self.assertEqual(index.last_applied_change_id, dataset.change_counter)
        dataset.sync_index(index)
        self.assertEqual(index.word_statistics[dictionary.identity_for("growth")]["collection_frequency"], 2)
        self.assertEqual(index.word_statistics[dictionary.identity_for("growth")]["document_frequency"], 2)

    def test_corrupt_history_triggers_reported_safe_rebuild(self):
        dictionary = make_dictionary()
        dataset = DatasetStore("corrupt-history")
        dataset.add_record("r1", {"text": "revenue"})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)
        dataset.add_record("r2", {"text": "growth"})
        dataset.change_log[-1]["action"] = "corrupt"
        result = dataset.sync_index(index)
        self.assertTrue(result["synchronized"])
        self.assertTrue(result["rebuilt"])
        self.assertIn("change_history_invalid", result["reason"])
        self.assertEqual(index.document_count, 2)

    def test_missing_duplicate_out_of_order_and_malformed_journals_are_recovered(self):
        mutations = (
            ("missing", lambda log: log.pop(0)),
            ("duplicate", lambda log: log.__setitem__(1, {**log[1], "change_id": log[0]["change_id"]})),
            ("out-of-order", lambda log: log.reverse()),
            ("malformed", lambda log: log.__setitem__(0, None)),
            ("wrong-generation", lambda log: log.__setitem__(0, {**log[0], "generation": "other"})),
        )
        for name, corrupt in mutations:
            dataset = DatasetStore(f"corrupt-{name}")
            dataset.add_record("r1", {"text": "revenue"})
            dataset.add_record("r2", {"text": "growth"})
            corrupt(dataset.change_log)
            index = DatasetIndex(dataset.dataset_id, dictionary_reference=make_dictionary())
            with self.subTest(journal=name):
                result = dataset.sync_index(index)
                self.assertTrue(result["synchronized"])
                self.assertTrue(result["rebuilt"])
                self.assertIn("change_history_invalid", result["reason"])
                self.assertEqual(index.document_count, 2)

    def test_temporal_mutation_boundaries_and_invalid_periods(self):
        dictionary = make_dictionary()
        dataset = DatasetStore("temporal-mutations")
        dataset.add_record("r1", {"text": "revenue", "date": "2024-01-01"})
        dataset.add_record("r2", {"text": "revenue revenue", "date": "2024-01-02"})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)
        old_period = {"start": "2024-01-01", "end": "2024-01-01"}
        new_period = {"start": "2024-01-02", "end": "2024-01-02"}
        self.assertEqual(index.temporal_frequency("revenue", time_field="date", period=old_period)["frequency"], 1)
        dataset.update_record("r1", {"text": "revenue", "date": "2024-01-02"})
        dataset.sync_index(index)
        self.assertEqual(index.temporal_frequency("revenue", time_field="date", period=old_period)["frequency"], 0)
        self.assertEqual(index.temporal_frequency("revenue", time_field="date", period=new_period)["frequency"], 3)
        with self.assertRaisesRegex(ValueError, "explicit"):
            index.temporal_frequency("revenue", time_field="date", period={})
        with self.assertRaisesRegex(ValueError, "after"):
            index.temporal_frequency(
                "revenue",
                time_field="date",
                period={"start": "2024-02-01", "end": "2024-01-01"},
            )

    def test_temporal_missing_invalid_and_timezone_values_are_reported(self):
        dictionary = make_dictionary()
        dataset = DatasetStore("temporal-quality")
        dataset.add_record("aware", {"text": "revenue", "timestamp": "2024-01-01T02:00:00+02:00"})
        dataset.add_record("missing", {"text": "revenue"})
        dataset.add_record("invalid", {"text": "revenue", "timestamp": "not-a-timestamp"})
        index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)
        period = {
            "start": "2024-01-01T00:00:00+00:00",
            "end": "2024-01-01T00:00:00+00:00",
        }
        stats = index.temporal_frequency("revenue", time_field="timestamp", period=period)
        self.assertEqual(stats["frequency"], 1)
        self.assertEqual(stats["missing_timestamp_count"], 1)
        self.assertEqual(stats["invalid_timestamp_count"], 1)
        self.assertFalse(stats["coverage_complete"])
        self.assertTrue(stats["warnings"])

    def test_sort_contract_supports_scalars_dates_nested_paths_and_missing_last(self):
        adapter = EvidenceAdapter()
        records = [
            {"record_id": "b", "content": {"meta": {"rank": 2}}},
            {"record_id": "c", "content": {"meta": {"rank": None}}},
            {"record_id": "a", "content": {"meta": {"rank": 2}}},
            {"record_id": "d", "content": {"meta": {"rank": 1}}},
        ]
        ordered = adapter._sort_evidence(records, "meta.rank")
        self.assertEqual([record_id for record_id, _ in ordered], ["d", "a", "b", "c"])
        descending = adapter._sort_evidence(records, "meta.rank", descending=True)
        self.assertEqual([record_id for record_id, _ in descending], ["a", "b", "d", "c"])
        dates = [
            {"record_id": "later", "date": "2024-03-01"},
            {"record_id": "earlier", "date": "2024-02-01"},
        ]
        self.assertEqual([item[0] for item in adapter._sort_evidence(dates, "date")], ["earlier", "later"])
        strings = [{"record_id": "b", "key": "beta"}, {"record_id": "a", "key": "alpha"}]
        self.assertEqual([item[0] for item in adapter._sort_evidence(strings, "key")], ["a", "b"])
        with self.assertRaisesRegex(ValueError, "mixed supported types"):
            adapter._sort_evidence(
                [{"record_id": "n", "key": 1}, {"record_id": "s", "key": "alpha"}],
                "key",
            )
        with self.assertRaisesRegex(ValueError, "mixes timezone-aware"):
            adapter._sort_evidence(
                [{"record_id": "aware", "key": "2024-01-01T00:00:00+00:00"}, {"record_id": "naive", "key": "2024-01-02T00:00:00"}],
                "key",
            )

    def test_benchmark_methodology_reports_equivalence_without_timing_thresholds(self):
        result = benchmark(sizes=(20,), repeats=1)
        small = result["sizes"]["20"]
        self.assertIn("median_seconds", small["full_index_construction"])
        self.assertIn("median_seconds", small["mutations"]["insert"])
        self.assertIn("retrieval", small["verification"])
        self.assertIn("solver", small["verification"])
        for query_result in small["queries"].values():
            self.assertTrue(query_result["equivalent_result_sets"], query_result)
        self.assertEqual(small["queries"]["growth"]["result_count"], 1)
        self.assertEqual(small["queries"]["missingterm"]["result_count"], 0)
        self.assertEqual(small["queries"]["revenue report"]["result_count"], 20)


if __name__ == "__main__":
    unittest.main()
