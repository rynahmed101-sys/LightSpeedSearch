from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable
from urllib.parse import urlencode

from dataset_index import DatasetIndex
from dictionary_reference import DictionaryReference
from query_locator import QueryLocator
from lss.search_engine import LocalSearchEngine


@dataclass(frozen=True)
class HistoricalSearchTarget:
    provider: str
    query: str
    start_year: int
    end_year: int
    url: str


class HistoricalSearchAdapter:
    """Generate date-bounded search URLs using the Search the Past reference logic."""

    @staticmethod
    def _date_to_oadate(year: int, month: int = 1, day: int = 1) -> int:
        from datetime import date, datetime

        base = datetime(1970, 1, 1)
        target = date(year, month, day)
        delta = target - base.date()
        return delta.days

    def build_url(self, provider: str, query: str, start_year: int, end_year: int) -> str:
        if not isinstance(provider, str):
            raise TypeError("provider must be a string")
        provider = provider.lower()
        if start_year > end_year:
            raise ValueError("start_year must be <= end_year")
        params = {
            "q": query,
        }
        if provider == "duckduckgo":
            date_filter = f"{start_year}-01-01..{end_year}-01-01"
            return "https://duckduckgo.com/?" + urlencode({**params, "df": date_filter, "ia": "web"})
        if provider == "google":
            return "https://www.google.com/search?" + urlencode({
                **params,
                "tbs": f"cdr:1,cd_min:1/1/{start_year},cd_max:12/31/{end_year}",
            })
        if provider == "bing":
            start_date = self._date_to_oadate(start_year, 1, 1)
            end_date = self._date_to_oadate(end_year, 12, 31)
            return "https://www.bing.com/search?" + urlencode({
                **params,
                "filters": f'ex1:"ez5_{start_date}_{end_date}"',
            })
        raise ValueError(f"Unsupported provider: {provider}")

    def generate_targets(self, query: str, provider: str | Iterable[str], start_year: int, end_year: int) -> list[HistoricalSearchTarget]:
        if isinstance(provider, str):
            providers = [provider]
        else:
            providers = list(provider)
        return [
            HistoricalSearchTarget(
                provider=choice,
                query=query,
                start_year=start_year,
                end_year=end_year,
                url=self.build_url(choice, query, start_year, end_year),
            )
            for choice in providers
        ]


class DictionaryFirstSearch:
    """Combine EWE dictionary identity with LSS local indexing and retrieval."""

    def __init__(self, dictionary_reference: DictionaryReference | None = None, dataset_store: Any | None = None) -> None:
        self.dictionary_reference = dictionary_reference or DictionaryReference()
        self.dataset_store = dataset_store
        self.local_engine = LocalSearchEngine()

    @staticmethod
    def tokenize_query(query: str) -> list[str]:
        return re.findall(r"[A-Za-z]+", query.lower())

    def supported_tokens(self, query: str) -> list[str]:
        return [token for token in self.tokenize_query(query) if self.dictionary_reference.lookup(token) is not None]

    def search_dataset(self, query: str, *, max_candidates: int = 10) -> dict[str, Any]:
        if self.dataset_store is None:
            return {
                "query": query,
                "tokens": self.tokenize_query(query),
                "supported_tokens": [],
                "unknown_tokens": [],
                "candidates": [],
                "retrieval_mode": "dataset-unavailable",
                "truncated": False,
            }
        if not hasattr(self.dataset_store, "dataset_id"):
            raise ValueError("dataset_store must expose dataset_id")
        index = DatasetIndex(self.dataset_store.dataset_id, dictionary_reference=self.dictionary_reference)
        self.dataset_store.sync_index(index)
        locator = QueryLocator(self.dictionary_reference, index)
        return locator.locate(query, max_candidates=max_candidates, retrieval_mode="dictionary-first")

    def search_local_documents(self, documents: Iterable[object], query: str, *, limit: int = 5) -> list[dict[str, Any]]:
        self.local_engine.index_documents(documents)
        return self.local_engine.search(query, limit=limit)

    def discover(self, documents: Iterable[object], query: str, *, limit_results: int = 5, max_candidates: int = 10) -> dict[str, Any]:
        local_results = self.search_local_documents(documents, query, limit=limit_results)
        dataset_results = self.search_dataset(query, max_candidates=max_candidates)
        return {
            "query": query,
            "supported_tokens": self.supported_tokens(query),
            "local_results": local_results,
            "dataset_candidates": dataset_results.get("candidates", []),
            "retrieval_metadata": {
                "dictionary_first": True,
                "dataset_available": self.dataset_store is not None,
                "truncated": dataset_results.get("truncated", False),
            },
        }
