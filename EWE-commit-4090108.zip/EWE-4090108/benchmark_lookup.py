from __future__ import annotations

import json
import random
import re
import statistics
import time
from typing import Any, Callable

from constraint_information import ConstraintSolver
from dataset_index import DatasetIndex
from dataset_store import DatasetStore
from dictionary_reference import DictionaryReference
from evidence_adapter import EvidenceAdapter
from query_locator import QueryLocator
from verification_engine import VerificationEngine


WORDS = ["revenue", "year", "growth", "sales", "market", "report", "north", "south"]
QUERIES = (
    "revenue",                    # common
    "growth",                     # rare
    "revenue report",             # sequence
    "missingterm",                # no match
)


def build_dataset(size: int = 5000, *, seed: int = 17) -> tuple[DatasetStore, DictionaryReference]:
    randomizer = random.Random(seed)
    dictionary = DictionaryReference(source="benchmark", version="demo", words=WORDS)
    dataset = DatasetStore("benchmark-dataset", source="synthetic")
    for index in range(size):
        year = 2000 + index
        region = "north" if randomizer.randrange(2) == 0 else "south"
        content = {
            "year": year,
            "revenue": 100 + index,
            "note": f"Revenue report {index} sales market year {year} {region}" + (" growth" if index % 20 == 0 else ""),
            "region": region,
        }
        dataset.add_record(f"record-{index}", content, source_location=f"location-{index}")
    return dataset, dictionary


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[A-Za-z]+", text.lower())


def _record_tokens(dataset: DatasetStore, record_id: str) -> list[str]:
    record = dataset.records[record_id]
    content = record.content
    if isinstance(content, str):
        text = content
    elif isinstance(content, dict) and isinstance(content.get("text"), str):
        text = content["text"]
    elif isinstance(content, dict):
        text = " ".join(f"{key} {value}" for key, value in content.items())
    elif isinstance(content, (list, tuple)):
        text = " ".join(map(str, content))
    else:
        text = str(content)
    return _tokenize(text)


def full_scan_lookup(dataset: DatasetStore, query: str) -> list[str]:
    terms = _tokenize(query)
    if not terms:
        return []
    matches = []
    for record_id in dataset.records:
        tokens = _record_tokens(dataset, record_id)
        if len(terms) == 1:
            qualifies = terms[0] in tokens
        else:
            qualifies = any(tokens[offset:offset + len(terms)] == terms for offset in range(len(tokens) - len(terms) + 1))
        if qualifies:
            matches.append(record_id)
    return sorted(matches)


def _ensure_index(dataset: DatasetStore, dictionary: DictionaryReference) -> DatasetIndex:
    index = DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary, max_sequence_length=4)
    dataset.sync_index(index)
    return index


def indexed_lookup(
    dataset: DatasetStore,
    dictionary: DictionaryReference,
    query: str,
    *,
    index: DatasetIndex | None = None,
) -> list[str]:
    index = index or _ensure_index(dataset, dictionary)
    terms = _tokenize(query)
    if not terms or any(dictionary.lookup(term) is None for term in terms):
        return []
    if len(terms) == 1:
        return sorted({item.record_id for item in index.lookup_word(terms[0])})
    return sorted({item.record_id for item in index.lookup_sequence(terms)})


def frequency_aware_lookup(
    dataset: DatasetStore,
    dictionary: DictionaryReference,
    query: str,
    *,
    index: DatasetIndex | None = None,
) -> list[str]:
    index = index or _ensure_index(dataset, dictionary)
    matches = indexed_lookup(dataset, dictionary, query, index=index)
    terms = _tokenize(query)
    scores: dict[str, float] = {record_id: 0.0 for record_id in matches}
    for term in terms:
        identity = dictionary.identity_for(term)
        if identity is None:
            continue
        stats = index.word_statistics.get(identity, {})
        document_frequency = stats.get("document_frequency", 0)
        for occurrence in index.lookup_word(identity):
            if occurrence.record_id in scores:
                scores[occurrence.record_id] += 1.0 / max(1, document_frequency)
    return sorted(matches, key=lambda record_id: (-scores[record_id], record_id))


def _measure(operation: Callable[[], Any], *, repeats: int = 7, warmups: int = 2) -> tuple[dict[str, float], Any]:
    for _ in range(warmups):
        operation()
    samples = []
    result: Any = None
    for _ in range(repeats):
        start = time.perf_counter()
        result = operation()
        samples.append(time.perf_counter() - start)
    quartiles = statistics.quantiles(samples, n=4, method="inclusive") if len(samples) > 1 else [samples[0]] * 3
    return {
        "median_seconds": statistics.median(samples),
        "iqr_seconds": quartiles[2] - quartiles[0],
        "minimum_seconds": min(samples),
        "maximum_seconds": max(samples),
    }, result


def _build_time(dataset: DatasetStore, dictionary: DictionaryReference, repeats: int) -> dict[str, float]:
    timing, _ = _measure(lambda: _ensure_index(dataset, dictionary), repeats=repeats, warmups=1)
    return timing


def _mutation_latency(dataset: DatasetStore, dictionary: DictionaryReference, action: str, repeats: int) -> dict[str, float]:
    samples = []
    for attempt in range(repeats):
        working, _ = build_dataset(size=len(dataset.records), seed=17)
        index = _ensure_index(working, dictionary)
        target = f"record-{len(working.records) - 1}"
        start = time.perf_counter()
        if action == "insert":
            working.add_record(f"new-{attempt}", {"year": 2030, "revenue": 9000, "note": "revenue growth market"}, source_location="new")
        elif action == "update":
            working.update_record(target, {"year": 2030, "revenue": 9000, "note": "revenue growth north"}, source_location="updated")
        else:
            working.remove_record(target)
        working.sync_index(index)
        samples.append(time.perf_counter() - start)
    quartiles = statistics.quantiles(samples, n=4, method="inclusive") if len(samples) > 1 else [samples[0]] * 3
    return {
        "median_seconds": statistics.median(samples),
        "iqr_seconds": quartiles[2] - quartiles[0],
        "minimum_seconds": min(samples),
        "maximum_seconds": max(samples),
    }


def _benchmark_size(size: int, repeats: int) -> dict[str, Any]:
    dataset, dictionary = build_dataset(size=size, seed=17)
    index = _ensure_index(dataset, dictionary)
    locator = QueryLocator(dictionary, index)
    result: dict[str, Any] = {
        "dataset_records": len(dataset.records),
        "full_index_construction": _build_time(dataset, dictionary, repeats),
        "queries": {},
    }
    for query in QUERIES:
        full_timing, full_results = _measure(lambda: full_scan_lookup(dataset, query), repeats=repeats)
        indexed_timing, indexed_results = _measure(
            lambda: indexed_lookup(dataset, dictionary, query, index=index), repeats=repeats
        )
        frequency_timing, frequency_results = _measure(
            lambda: frequency_aware_lookup(dataset, dictionary, query, index=index), repeats=repeats
        )
        correct = set(full_results) == set(indexed_results) == set(frequency_results)
        result["queries"][query] = {
            "full_scan": full_timing,
            "indexed_built_index": indexed_timing,
            "frequency_aware_built_index": frequency_timing,
            "result_count": len(full_results),
            "equivalent_result_sets": correct,
        }

    temporal_timing, temporal_result = _measure(
        lambda: index.compare_period_frequency(
            "revenue",
            previous_period={"start": 2000, "end": 2009},
            current_period={"start": 2010, "end": 2019},
            time_field="year",
        ),
        repeats=repeats,
    )
    result["temporal_comparison"] = {
        **temporal_timing,
        "previous_frequency": temporal_result["previous_frequency"],
        "current_frequency": temporal_result["current_frequency"],
        "coverage_complete": temporal_result["coverage_complete"],
    }

    condition = {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"}
    evidence = [
        {
            "record_id": record.record_id,
            "source_location": record.source_location,
            "content": record.content,
            "metadata": record.metadata,
        }
        for record in dataset.iter_records()
    ]
    adapter = EvidenceAdapter(dictionary)
    candidates = locator.locate("revenue report", max_candidates=None)["candidates"]
    retrieval_timing, _ = _measure(
        lambda: locator.locate("revenue report", max_candidates=None, retrieval_mode="verification"),
        repeats=repeats,
    )
    adapter_result = adapter.build_solver_input("revenue report", condition, candidates, evidence)
    solver_timing, _ = _measure(
        lambda: ConstraintSolver(adapter_result.domains, adapter_result.constraints).decision()
        if adapter_result.domains and not adapter_result.unresolved
        else False,
        repeats=repeats,
    )
    engine = VerificationEngine(dictionary_reference=dictionary, dataset_index=index)
    verification_timing, verification_result = _measure(
        lambda: engine.verify_query(dataset, "revenue report", condition, max_candidates=None),
        repeats=repeats,
    )
    result["verification"] = {
        "end_to_end": verification_timing,
        "retrieval": retrieval_timing,
        "solver": solver_timing,
        "status": verification_result.status.value,
        "solver_outcome": verification_result.solver_outcome,
    }
    result["mutations"] = {
        action: _mutation_latency(dataset, dictionary, action, repeats)
        for action in ("insert", "update", "delete")
    }
    mutated, _ = build_dataset(size=size, seed=17)
    mutated_index = _ensure_index(mutated, dictionary)
    for action in ("insert", "update", "delete"):
        target = f"record-{len(mutated.records) - 1}"
        if action == "insert":
            mutated.add_record("rebuild-new", {"year": 2030, "revenue": 1, "note": "revenue growth"}, source_location="new")
        elif action == "update":
            mutated.update_record(target, {"year": 2030, "revenue": 2, "note": "market north"}, source_location="updated")
        else:
            mutated.remove_record(target)
    mutated.sync_index(mutated_index)
    rebuild_timing, _ = _measure(lambda: mutated_index.rebuild(mutated), repeats=repeats, warmups=1)
    result["full_rebuild_after_mutations"] = rebuild_timing
    result["mutation_correctness"] = mutated_index.as_dict()["document_count"] == len(mutated.records)
    return result


def benchmark(*, sizes: tuple[int, ...] = (50,  500), repeats: int = 7) -> dict[str, Any]:
    return {
        "methodology": {
            "seed": 17,
            "warmups": 2,
            "repeats": repeats,
            "summary": "median and interquartile range; query index is built before query timing",
            "matching": "exact lexical token or contiguous sequence; equivalent result sets are checked",
        },
        "sizes": {str(size): _benchmark_size(size, repeats) for size in sizes},
    }


if __name__ == "__main__":
    print(json.dumps(benchmark(), indent=2, sort_keys=True))
