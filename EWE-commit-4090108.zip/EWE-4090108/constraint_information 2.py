"""Finite-domain constraint solving with state-space reduction metrics."""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass
from itertools import product
from typing import Callable, Hashable, Iterable, Iterator, Mapping


Variable = Hashable
Value = Hashable


@dataclass(frozen=True)
class Constraint:
    """A predicate over values assigned to the variables in ``scope``."""

    scope: tuple[Variable, ...]
    predicate: Callable[..., bool]
    name: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "scope", tuple(self.scope))
        if not self.scope:
            raise ValueError("a constraint must refer to at least one variable")
        if len(set(self.scope)) != len(self.scope):
            raise ValueError("a constraint scope cannot contain duplicate variables")
        if not callable(self.predicate):
            raise TypeError("constraint predicate must be callable")


@dataclass(frozen=True)
class SoftConstraint:
    """A predicate that contributes a nonnegative penalty when it is violated."""

    constraint: Constraint
    weight: float = 1.0

    def __post_init__(self) -> None:
        if not isinstance(self.constraint, Constraint):
            raise TypeError("soft constraint must wrap a Constraint")
        if not isinstance(self.weight, (int, float)) or not math.isfinite(self.weight):
            raise ValueError("soft-constraint weight must be a finite number")
        if self.weight < 0:
            raise ValueError("soft-constraint weight cannot be negative")


@dataclass(frozen=True)
class PropagationResult:
    """Domains remaining after propagation reaches a fixed point."""

    domains: dict[Variable, tuple[Value, ...]]
    consistent: bool
    revisions: int


class ConstraintSolver:
    """Solve a finite-domain CSP using generalized arc consistency and search."""

    def __init__(
        self,
        domains: Mapping[Variable, Iterable[Value]],
        constraints: Iterable[Constraint],
    ) -> None:
        self.domains: dict[Variable, tuple[Value, ...]] = {}
        for variable, values in domains.items():
            values_tuple = tuple(dict.fromkeys(values))
            if not values_tuple:
                raise ValueError(f"domain for {variable!r} cannot be empty")
            self.domains[variable] = values_tuple

        if not self.domains:
            raise ValueError("at least one variable is required")

        self.constraints = tuple(constraints)
        for constraint in self.constraints:
            unknown = set(constraint.scope).difference(self.domains)
            if unknown:
                raise ValueError(f"constraint refers to unknown variables: {unknown!r}")
        self._constraints_by_variable = {
            variable: tuple(
                index
                for index, constraint in enumerate(self.constraints)
                if variable in constraint.scope
            )
            for variable in self.domains
        }
        self._support_cache: dict[tuple[int, int, Value], tuple[Value, ...]] = {}

    def propagate(
        self, domains: Mapping[Variable, Iterable[Value]] | None = None
    ) -> PropagationResult:
        """Remove unsupported values until every constraint is locally consistent."""
        initial_domains = self.domains if domains is None else domains
        working = {
            variable: tuple(values)
            for variable, values in initial_domains.items()
        }
        if set(working) != set(self.domains):
            raise ValueError("provided domains must contain exactly the solver variables")
        if any(
            not set(values).issubset(self.domains[variable])
            for variable, values in working.items()
        ):
            raise ValueError("provided domains cannot contain values outside the original domains")
        if any(not values for values in working.values()):
            return PropagationResult(working, False, 0)
        revisions = 0
        queue = deque(
            (constraint_index, target_index)
            for constraint_index, constraint in enumerate(self.constraints)
            for target_index in range(len(constraint.scope))
        )
        queued = set(queue)

        while queue:
            constraint_index, target_index = queue.popleft()
            queued.remove((constraint_index, target_index))
            constraint = self.constraints[constraint_index]
            variable = constraint.scope[target_index]
            supported = tuple(
                value
                for value in working[variable]
                if self._has_support(
                    working, constraint_index, target_index, value
                )
            )
            if len(supported) == len(working[variable]):
                continue

            revisions += len(working[variable]) - len(supported)
            working[variable] = supported
            if not supported:
                return PropagationResult(working, False, revisions)

            for adjacent_index in self._constraints_by_variable[variable]:
                adjacent = self.constraints[adjacent_index]
                for adjacent_target, other_variable in enumerate(adjacent.scope):
                    if other_variable == variable:
                        continue
                    arc = (adjacent_index, adjacent_target)
                    if arc not in queued:
                        queue.append(arc)
                        queued.add(arc)

        return PropagationResult(working, True, revisions)

    def _has_support(
        self,
        domains: Mapping[Variable, tuple[Value, ...]],
        constraint_index: int,
        target_index: int,
        target_value: Value,
    ) -> bool:
        constraint = self.constraints[constraint_index]
        cache_key = (constraint_index, target_index, target_value)
        cached_support = self._support_cache.get(cache_key)
        if cached_support is not None and all(
            value in domains[variable]
            for variable, value in zip(constraint.scope, cached_support)
        ):
            return True

        scoped_domains = [
            (target_value,) if index == target_index else domains[variable]
            for index, variable in enumerate(constraint.scope)
        ]
        for values in product(*scoped_domains):
            if constraint.predicate(*values):
                self._support_cache[cache_key] = values
                return True
        return False

    def verify(self, assignment: Mapping[Variable, Value]) -> bool:
        """Return whether a complete assignment satisfies domains and constraints."""
        if any(variable not in assignment for variable in self.domains):
            return False
        if any(
            assignment[variable] not in values
            for variable, values in self.domains.items()
        ):
            return False
        return all(
            constraint.predicate(*(assignment[variable] for variable in constraint.scope))
            for constraint in self.constraints
        )

    def solutions(self, limit: int | None = None) -> Iterator[dict[Variable, Value]]:
        """Yield satisfying assignments; optionally stop after ``limit`` results."""
        if limit is not None and limit < 0:
            raise ValueError("limit cannot be negative")
        if limit == 0:
            return

        yielded = 0
        for assignment in self._search(self.domains):
            yield assignment
            yielded += 1
            if limit is not None and yielded >= limit:
                return

    def _search(
        self, domains: Mapping[Variable, Iterable[Value]]
    ) -> Iterator[dict[Variable, Value]]:
        result = self.propagate(domains)
        if not result.consistent:
            return

        unresolved = [
            variable
            for variable, values in result.domains.items()
            if len(values) > 1
        ]
        if not unresolved:
            assignment = {
                variable: values[0] for variable, values in result.domains.items()
            }
            if self.verify(assignment):
                yield assignment
            return

        variable = min(unresolved, key=lambda item: len(result.domains[item]))
        for value in result.domains[variable]:
            branch = dict(result.domains)
            branch[variable] = (value,)
            yield from self._search(branch)

    def solve_one(self) -> dict[Variable, Value] | None:
        """Return one satisfying assignment, or ``None`` when none exists."""
        return next(self.solutions(limit=1), None)

    def decision(self) -> bool:
        """Answer whether the constraint system has at least one solution."""
        return self.solve_one() is not None

    def count_solutions(self) -> int:
        """Count all satisfying assignments exactly."""
        return sum(1 for _ in self.solutions())

    def optimize(
        self,
        objective: Callable[[Mapping[Variable, Value]], float | int],
        minimize: bool = True,
        limit: int | None = None,
        objective_bound: Callable[
            [Mapping[Variable, tuple[Value, ...]]], float | int
        ]
        | None = None,
    ) -> Iterator[tuple[float | int, dict[Variable, Value]]]:
        """Yield improving feasible assignments using branch-and-bound.

        Results are incumbent improvements, not a sorted list. After exhausting
        the iterator, the last result is globally optimal. ``objective_bound``
        may return an optimistic lower bound for minimization or upper bound for
        maximization. It must be valid for every completion of the supplied
        domains; without it, all feasible assignments may need to be explored.
        ``limit`` stops after that many incumbent improvements, so the final
        result is not necessarily globally optimal when a limit is reached.
        """
        if limit is not None and limit < 0:
            raise ValueError("limit cannot be negative")
        if limit == 0:
            return
        if not callable(objective):
            raise TypeError("objective must be callable")
        if objective_bound is not None and not callable(objective_bound):
            raise TypeError("objective_bound must be callable")

        best_value: float | int | None = None
        yielded = 0

        def search(
            domains: Mapping[Variable, Iterable[Value]],
        ) -> Iterator[tuple[float | int, dict[Variable, Value]]]:
            nonlocal best_value, yielded
            result = self.propagate(domains)
            if not result.consistent:
                return

            if objective_bound is not None and best_value is not None:
                optimistic_value = objective_bound(result.domains)
                self._validate_objective_value(optimistic_value, "objective bound")
                if minimize and optimistic_value >= best_value:
                    return
                if not minimize and optimistic_value <= best_value:
                    return

            unresolved = [
                variable
                for variable, values in result.domains.items()
                if len(values) > 1
            ]
            if not unresolved:
                assignment = {
                    variable: values[0]
                    for variable, values in result.domains.items()
                }
                if not self.verify(assignment):
                    return
                value = objective(assignment)
                self._validate_objective_value(value, "objective")
                improved = (
                    best_value is None
                    or (value < best_value if minimize else value > best_value)
                )
                if improved:
                    best_value = value
                    yielded += 1
                    yield value, assignment
                return

            variable = min(unresolved, key=lambda item: len(result.domains[item]))
            for value in result.domains[variable]:
                branch = dict(result.domains)
                branch[variable] = (value,)
                yield from search(branch)
                if limit is not None and yielded >= limit:
                    return

        yield from search(self.domains)

    @staticmethod
    def _validate_objective_value(value: float | int, label: str) -> None:
        if not isinstance(value, (int, float)) or (
            isinstance(value, float) and math.isnan(value)
        ):
            raise ValueError(f"{label} must return a number other than NaN")

    def minimize_penalty(
        self,
        soft_constraints: Iterable[SoftConstraint],
        limit: int | None = None,
    ) -> Iterator[tuple[float | int, dict[Variable, Value]]]:
        """Minimize weighted soft-constraint violations over hard-feasible states.

        Put all conflicting requirements in ``soft_constraints`` and leave only
        mandatory requirements in this solver's hard ``constraints``. The bound
        sums penalties for soft constraints that have no satisfying tuple left
        in the current domains, which is admissible for nonnegative weights.
        """
        soft_constraints = tuple(soft_constraints)
        for soft_constraint in soft_constraints:
            unknown = set(soft_constraint.constraint.scope).difference(self.domains)
            if unknown:
                raise ValueError(f"soft constraint refers to unknown variables: {unknown!r}")

        def penalty(assignment: Mapping[Variable, Value]) -> float | int:
            return sum(
                soft_constraint.weight
                for soft_constraint in soft_constraints
                if not soft_constraint.constraint.predicate(
                    *(assignment[variable] for variable in soft_constraint.constraint.scope)
                )
            )

        def penalty_lower_bound(
            domains: Mapping[Variable, tuple[Value, ...]],
        ) -> float | int:
            unavoidable = 0
            for soft_constraint in soft_constraints:
                constraint = soft_constraint.constraint
                has_satisfying_tuple = any(
                    constraint.predicate(*values)
                    for values in product(
                        *(domains[variable] for variable in constraint.scope)
                    )
                )
                if not has_satisfying_tuple:
                    unavoidable += soft_constraint.weight
            return unavoidable

        return self.optimize(
            penalty,
            minimize=True,
            limit=limit,
            objective_bound=penalty_lower_bound,
        )

    def information_reduction_bits(self) -> float:
        """Return log2(initial assignments / satisfying assignments).

        An unsatisfiable system has no admissible states, so its reduction is
        represented as positive infinity, matching the attached blueprint.
        """
        initial_count = math.prod(len(values) for values in self.domains.values())
        solution_count = self.count_solutions()
        if solution_count == 0:
            return math.inf
        return math.log2(initial_count / solution_count)


def inequality_cycle(size: int) -> ConstraintSolver:
    """Build a binary cycle whose neighboring variables must differ."""
    if size < 2:
        raise ValueError("cycle size must be at least 2")
    variables = tuple(range(size))
    constraints = tuple(
        Constraint(
            (variables[index], variables[(index + 1) % size]),
            lambda left, right: left != right,
            name=f"edge_{index}",
        )
        for index in range(size)
    )
    return ConstraintSolver({variable: (0, 1) for variable in variables}, constraints)


def even_parity_solver() -> ConstraintSolver:
    """Build the three-bit even-parity example from the attached blueprint."""
    return ConstraintSolver(
        {"a": (0, 1), "b": (0, 1), "c": (0, 1)},
        (Constraint(("a", "b", "c"), lambda a, b, c: (a ^ b ^ c) == 0),),
    )


def main() -> None:
    for label, solver in (
        ("Even parity (3 variables)", even_parity_solver()),
        ("Even inequality cycle (4 variables)", inequality_cycle(4)),
        ("Odd inequality cycle (3 variables)", inequality_cycle(3)),
    ):
        propagation = solver.propagate()
        count = solver.count_solutions()
        print(label)
        print(f"  locally consistent: {propagation.consistent}")
        print(f"  fixed-point domains: {propagation.domains}")
        print(f"  solutions: {count}")
        print(f"  information reduction: {solver.information_reduction_bits():.4g} bits")
        print(f"  sample solution: {solver.solve_one()}\n")

    parity = even_parity_solver()
    best_assignment = list(
        parity.optimize(
            lambda assignment: 2 * assignment["a"]
            + assignment["b"]
            + assignment["c"]
        )
    )[-1]
    print("Minimum-cost even-parity assignment")
    print(f"  cost: {best_assignment[0]}")
    print(f"  assignment: {best_assignment[1]}\n")

    preference_solver = ConstraintSolver({"choice": (0, 1)}, ())
    preferences = (
        SoftConstraint(Constraint(("choice",), lambda value: value == 0), weight=2),
        SoftConstraint(Constraint(("choice",), lambda value: value == 1), weight=1),
    )
    best_preference = list(preference_solver.minimize_penalty(preferences))[-1]
    print("Minimum-penalty soft-constraint assignment")
    print(f"  penalty: {best_preference[0]}")
    print(f"  assignment: {best_preference[1]}")


if __name__ == "__main__":
    main()