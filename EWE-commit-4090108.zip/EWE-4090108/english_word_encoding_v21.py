"""Compatibility module for the v2.2 implementation."""

from english_word_encoding_v22 import (
    ASCII_WORD,
    BASE,
    audit_wordlist,
    compare,
    decode,
    edit_distance,
    encode,
    main,
    normalize,
    parse_identity_argument,
    render_json,
    self_test,
)

__all__ = [
    "ASCII_WORD",
    "BASE",
    "audit_wordlist",
    "compare",
    "decode",
    "edit_distance",
    "encode",
    "main",
    "normalize",
    "parse_identity_argument",
    "render_json",
    "self_test",
]


if __name__ == "__main__":
    main()