#!/usr/bin/env python3
"""English Word Encoding v2.2

Loads a newline-delimited word list, normalizes ASCII English spellings,
encodes each spelling as a unique base-27 integer, and checks invariants.

Usage:
    python english_word_encoding_v22.py --self-test
    python english_word_encoding_v22.py --word cat
    python english_word_encoding_v22.py --decode 2234
    python english_word_encoding_v22.py --compare cat cot
    python english_word_encoding_v22.py --wordlist words.txt --provenance source.json --report report.json

Input word-list format: one candidate word per line. Lines may contain
punctuation or spaces; candidates are accepted only if the entire trimmed
line consists of ASCII letters A-Z/a-z. This is a spelling prototype, not
a complete definition of English vocabulary.
"""

import argparse
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

BASE = 27
ASCII_WORD = re.compile(r"^[A-Za-z]+$")


def normalize(word: str) -> str:
    if not isinstance(word, str):
        raise TypeError("word must be a string")
    word = word.strip()
    if not ASCII_WORD.fullmatch(word):
        raise ValueError("Expected one word made only of ASCII letters A-Z.")
    return word.lower()


def encode(word: str) -> dict:
    normalized = normalize(word)
    vector = [ord(ch) - ord("a") + 1 for ch in normalized]

    identity = 0
    for value in vector:
        identity = identity * BASE + value

    return {
        "word": normalized,
        "identity": identity,
        "vector": vector,
    }


def decode(identity: int) -> str:
    """Decode a positive base-27 identity into its normalized spelling."""
    if type(identity) is not int:
        raise TypeError("identity must be an integer")
    if identity <= 0:
        raise ValueError("identity must be a positive integer")

    letters = []
    while identity:
        value = identity % BASE
        if value == 0:
            raise ValueError("identity is not a valid spelling code")
        letters.append(chr(ord("a") + value - 1))
        identity //= BASE
    return "".join(reversed(letters))


def parse_identity_argument(value: str) -> int:
    """Parse a decimal CLI identity without Python's long-integer digit limit."""
    if not re.fullmatch(r"-?[0-9]+", value):
        raise argparse.ArgumentTypeError("identity must be a decimal integer")

    negative = value.startswith("-")
    digits = value[1:] if negative else value
    identity = 0
    for offset in range(0, len(digits), 9):
        chunk = digits[offset:offset + 9]
        identity = identity * (10 ** len(chunk)) + int(chunk)
    return -identity if negative else identity


def edit_distance(a: str, b: str) -> int:
    """Levenshtein distance: insertions, deletions, and substitutions."""
    if len(b) > len(a):
        a, b = b, a
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(min(
                current[-1] + 1,          # insertion
                previous[j] + 1,          # deletion
                previous[j - 1] + (ca != cb),  # substitution
            ))
        previous = current
    return previous[-1]


def compare(a: str, b: str) -> dict:
    left = encode(a)
    right = encode(b)
    distance = edit_distance(left["word"], right["word"])
    longest = max(len(left["word"]), len(right["word"]))
    similarity = 1.0 - distance / longest
    return {
        "word_a": left,
        "word_b": right,
        "edit_distance": distance,
        "normalized_spelling_similarity": round(similarity, 4),
        "similarity_definition": "1 - edit_distance / max(word lengths)",
    }


def audit_wordlist(path: Path, provenance: dict | None = None) -> dict:
    accepted = []
    rejected = []
    raw_spellings = defaultdict(set)
    physical_lines = 0
    candidate_entries = 0
    with path.open("r", encoding="utf-8-sig") as handle:
        for line_number, line in enumerate(handle, 1):
            physical_lines = line_number
            candidate = line.strip()
            if not candidate or candidate.startswith("#"):
                continue
            candidate_entries += 1
            try:
                normalized = normalize(candidate)
                accepted.append(normalized)
                raw_spellings[normalized].add(candidate)
            except ValueError:
                if not candidate.isascii():
                    reason = "contains non-ASCII characters"
                elif any(character.isspace() for character in candidate):
                    reason = "contains whitespace"
                else:
                    reason = "contains non-letter ASCII characters"
                rejected.append({
                    "line": line_number,
                    "value": candidate,
                    "reason": reason,
                })

    unique_words = sorted(set(accepted))
    duplicate_entries = {
        word: count for word, count in Counter(accepted).items() if count > 1
    }
    encoded = [(word, encode(word)["identity"]) for word in unique_words]
    code_counts = Counter(code for _, code in encoded)
    collisions = {
        str(code): [word for word, assigned in encoded if assigned == code]
        for code, count in code_counts.items()
        if count > 1
    }
    round_trip_failures = [
        word for word, code in encoded if decode(code) != word
    ]
    rejected_by_reason = Counter(item["reason"] for item in rejected)

    return {
        "source_file": str(path),
        "physical_lines": physical_lines,
        "total_entries_before_normalization": candidate_entries,
        "candidate_entries_before_normalization": candidate_entries,
        "accepted_entries_after_normalization": len(accepted),
        "accepted_entries_including_duplicates": len(accepted),
        "unique_normalized_spellings": len(unique_words),
        "duplicate_entries": duplicate_entries,
        "duplicate_entry_count": sum(count - 1 for count in duplicate_entries.values()),
        "normalization_variants": {
            word: sorted(variants)
            for word, variants in sorted(raw_spellings.items())
            if len(variants) > 1
        },
        "rejected_entries_count": len(rejected),
        "rejected_entries_by_reason": dict(sorted(rejected_by_reason.items())),
        "rejected_entries": rejected,
        "rejected_entries_sample": rejected[:50],
        "distinct_identity_codes": len(set(code for _, code in encoded)),
        "identity_collisions": collisions,
        "collision_check_passed": not collisions,
        "round_trip_checked_spellings": len(encoded),
        "round_trip_failures": round_trip_failures,
        "round_trip_check_passed": not round_trip_failures,
        "lexical_classification": {
            "status": "not assessed",
            "reason": "The supplied plain-text list does not reliably label language, proper names, abbreviations, or other lexical classes.",
        },
        "dataset_provenance": provenance,
        "sample_encodings": [
            encode(word) for word in unique_words[:20]
        ],
        "limitations": [
            "Coverage depends entirely on the supplied word list.",
            "Only ASCII A-Z spellings are accepted.",
            "A word list may include names, abbreviations, or non-English words.",
            "Identity codes encode spelling, not pronunciation or meaning.",
        ],
    }


def _decimal_string(value: int) -> str:
    """Convert an integer to decimal in small chunks, bypassing digit limits."""
    if value == 0:
        return "0"
    negative = value < 0
    value = abs(value)
    chunks = []
    while value:
        value, remainder = divmod(value, 1_000_000_000)
        chunks.append(remainder)
    rendered = str(chunks.pop()) + "".join(f"{chunk:09d}" for chunk in reversed(chunks))
    return "-" + rendered if negative else rendered


def render_json(result: dict) -> str:
    """Render results even when identities exceed Python's decimal digit limit."""
    serialization_notes = []

    def convert(value):
        if isinstance(value, dict):
            return {key: convert(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [convert(item) for item in value]
        if type(value) is int:
            try:
                str(value)
            except ValueError:
                serialization_notes.append(
                    "Integers exceeding Python's decimal digit limit are emitted as decimal strings."
                )
                return _decimal_string(value)
        return value

    safe_result = convert(result)
    if serialization_notes and isinstance(safe_result, dict):
        safe_result["serialization_notes"] = sorted(set(serialization_notes))
    return json.dumps(safe_result, indent=2, ensure_ascii=False)


def self_test() -> None:
    expected = {
        "a": 1,
        "b": 2,
        "cat": 2234,
        "cot": 2612,
        "dog": 3328,
        "cats": 60337,
    }
    for word, expected_code in expected.items():
        assert encode(word)["identity"] == expected_code
        assert decode(expected_code) == word

    assert encode("CAT") == encode("cat")
    assert edit_distance("cat", "cot") == 1
    assert edit_distance("cat", "cats") == 1
    assert edit_distance("cat", "dog") == 3

    # Verify uniqueness across all short strings over a small alphabet.
    samples = [
        "a", "b", "c", "aa", "ab", "ba", "bb",
        "aaa", "aab", "aba", "abb", "baa", "bab", "bba", "bbb",
    ]
    codes = [encode(word)["identity"] for word in samples]
    assert len(codes) == len(set(codes))

    for invalid in ("", "hello world", "can't", "ice-cream", "café", "123"):
        try:
            encode(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Invalid input unexpectedly accepted: {invalid!r}")

    for invalid_code in (0, -1, 27):
        try:
            decode(invalid_code)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Invalid code unexpectedly accepted: {invalid_code!r}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--word", help="Encode one spelling")
    parser.add_argument("--decode", type=parse_identity_argument, metavar="IDENTITY", help="Decode a decimal identity")
    parser.add_argument("--compare", nargs=2, metavar=("WORD_A", "WORD_B"))
    parser.add_argument("--wordlist", type=Path, help="One candidate spelling per line")
    parser.add_argument("--provenance", type=Path, help="Optional JSON dataset provenance")
    parser.add_argument("--report", type=Path, help="Optional JSON report output path")
    args = parser.parse_args()

    if args.self_test:
        self_test()
        print("All tests passed.")
        return

    if args.word:
        result = encode(args.word)
    elif args.decode is not None:
        try:
            word = decode(args.decode)
        except ValueError as error:
            parser.error(str(error))
        result = {"identity": args.decode, "word": word}
    elif args.compare:
        result = compare(*args.compare)
    elif args.wordlist:
        provenance = (
            json.loads(args.provenance.read_text(encoding="utf-8"))
            if args.provenance else None
        )
        result = audit_wordlist(args.wordlist, provenance)
    else:
        parser.error("Choose --self-test, --word, --decode, --compare, or --wordlist.")

    rendered = render_json(result)
    if args.report:
        args.report.write_text(rendered + "\n", encoding="utf-8")
        print(f"Report written to {args.report}")
    else:
        print(rendered)


if __name__ == "__main__":
    main()
