from __future__ import annotations

import hashlib
import re
import tarfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Iterator, Sequence

from english_word_encoding_v22 import decode, encode, normalize


@dataclass(frozen=True)
class DictionaryEntry:
    word: str
    identity: int
    vector: tuple[int, ...]
    source: str = "user-supplied"
    version: str | None = None


class DictionaryReference:
    """Versioned registry of normalized English spellings.

    The dictionary establishes stable word identities; it does not claim any
    meaning or truth for sentences or records.
    """

    def __init__(
        self,
        source: str = "user-supplied",
        version: str | None = None,
        license: str | None = None,
        acquisition_details: str | None = None,
        words: Iterable[str] | None = None,
        *,
        dictionary_path: str | Path | None = None,
    ) -> None:
        self.source = source
        self.version = version
        self.license = license
        self.acquisition_details = acquisition_details
        self.dictionary_path = Path(dictionary_path) if dictionary_path else None
        self.content_hash = self._hash_path(self.dictionary_path) if self.dictionary_path else None
        self.entries: dict[str, DictionaryEntry] = {}
        self.identity_to_word: dict[int, str] = {}
        self.rejected: list[dict[str, object]] = []
        self.accepted_history: list[str] = []
        self._meta: dict[str, object] = {}
        if words is not None:
            self.load_words(words)
        elif self.dictionary_path is not None:
            self.load_from_path(self.dictionary_path)

    @staticmethod
    def _hash_path(path: str | Path | None) -> str | None:
        if path is None:
            return None
        hash_obj = hashlib.sha256()
        with Path(path).open("rb") as handle:
            for chunk in iter(lambda: handle.read(65536), b""):
                hash_obj.update(chunk)
        return hash_obj.hexdigest()

    @property
    def metadata(self) -> dict[str, object]:
        return {
            "source": self.source,
            "version": self.version,
            "license": self.license,
            "acquisition_details": self.acquisition_details,
            "content_hash": self.content_hash,
            "dictionary_path": str(self.dictionary_path) if self.dictionary_path else None,
            "entry_count": len(self.entries),
            "rejected_count": len(self.rejected),
            "versioned": self.version is not None,
        }

    @staticmethod
    def _extract_words_from_text(text: str) -> list[str]:
        words: list[str] = []
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if stripped.startswith("This software and database"):
                continue
            match = re.match(r"([A-Za-z]+)", stripped)
            if match:
                words.append(match.group(1).lower())
        return words

    def load_from_path(self, path: str | Path | None = None) -> dict[str, DictionaryEntry]:
        target = Path(path) if path is not None else self.dictionary_path
        if target is None:
            return {}
        path_obj = Path(target)
        if not path_obj.exists():
            raise FileNotFoundError(f"dictionary path not found: {path_obj}")

        candidates: list[str] = []
        if path_obj.is_dir():
            for child in sorted(path_obj.rglob("index.*")):
                if child.is_file():
                    candidates.extend(self._extract_words_from_text(child.read_text(encoding="utf-8", errors="ignore")))
            if not candidates:
                for child in sorted(path_obj.rglob("*.txt")):
                    if child.is_file():
                        candidates.extend(self._extract_words_from_text(child.read_text(encoding="utf-8", errors="ignore")))
        elif path_obj.name.endswith(".tar.gz") or path_obj.name.endswith(".tgz"):
            with tarfile.open(path_obj, "r:gz") as archive:
                for member in sorted(archive.getmembers(), key=lambda item: item.name):
                    if not member.isfile():
                        continue
                    name = member.name.lower()
                    if "index." not in name and not name.endswith(".txt"):
                        continue
                    payload = archive.extractfile(member)
                    if payload is None:
                        continue
                    text = payload.read().decode("utf-8", errors="ignore")
                    candidates.extend(self._extract_words_from_text(text))
        else:
            candidates.extend(self._extract_words_from_text(path_obj.read_text(encoding="utf-8", errors="ignore")))

        if not candidates:
            return {}
        return self.load_words(candidates)

    def load_words(self, words: Iterable[str]) -> dict[str, DictionaryEntry]:
        """Reset and repopulate the dictionary from a sequence of word strings."""
        self.entries = {}
        self.identity_to_word = {}
        self.rejected = []
        self.accepted_history = []
        for index, raw_word in enumerate(words):
            if raw_word is None:
                continue
            candidate = str(raw_word).strip()
            if not candidate or candidate.startswith("#"):
                continue
            try:
                normalized = normalize(candidate)
                result = encode(normalized)
                if decode(result["identity"]) != normalized:
                    raise ValueError("identity round-trip mismatch")
            except (TypeError, ValueError) as exc:
                self.rejected.append({
                    "line": index,
                    "value": candidate,
                    "reason": str(exc),
                })
                continue
            entry = DictionaryEntry(
                word=normalized,
                identity=result["identity"],
                vector=tuple(result["vector"]),
                source=self.source,
                version=self.version,
            )
            self.entries[normalized] = entry
            self.identity_to_word[entry.identity] = normalized
            self.accepted_history.append(normalized)
        return dict(self.entries)

    def replace_dictionary(self, words: Iterable[str], *, source: str | None = None, version: str | None = None, license: str | None = None, acquisition_details: str | None = None, dictionary_path: str | Path | None = None) -> dict[str, DictionaryEntry]:
        if source is not None:
            self.source = source
        if version is not None:
            self.version = version
        if license is not None:
            self.license = license
        if acquisition_details is not None:
            self.acquisition_details = acquisition_details
        if dictionary_path is not None:
            self.dictionary_path = Path(dictionary_path)
            self.content_hash = self._hash_path(self.dictionary_path)
        return self.load_words(words)

    def lookup(self, word: str) -> DictionaryEntry | None:
        try:
            normalized = normalize(word)
        except (TypeError, ValueError):
            return None
        return self.entries.get(normalized)

    def identity_for(self, word: str) -> int | None:
        entry = self.lookup(word)
        return None if entry is None else entry.identity

    def word_for_identity(self, identity: int) -> str | None:
        if type(identity) is not int:
            raise TypeError("identity must be an integer")
        return self.identity_to_word.get(identity)

    def encode(self, word: str) -> int:
        entry = self.lookup(word)
        if entry is None:
            raise KeyError(f"word {word!r} is not present in the dictionary")
        return entry.identity

    def decode(self, identity: int) -> str:
        decoded = decode(identity)
        if self.identity_to_word.get(identity) is not None:
            return self.identity_to_word[identity]
        return decoded

    def contains(self, word: str) -> bool:
        return self.lookup(word) is not None

    def __contains__(self, word: str) -> bool:
        return self.contains(word)

    def __len__(self) -> int:
        return len(self.entries)

    def iter_words(self) -> Iterator[str]:
        yield from sorted(self.entries)

    def as_dict(self) -> dict[str, object]:
        return {
            "source": self.source,
            "version": self.version,
            "license": self.license,
            "acquisition_details": self.acquisition_details,
            "content_hash": self.content_hash,
            "dictionary_path": str(self.dictionary_path) if self.dictionary_path else None,
            "entries": {word: {"identity": entry.identity, "vector": list(entry.vector)} for word, entry in sorted(self.entries.items())},
            "rejected_entries": self.rejected,
        }
