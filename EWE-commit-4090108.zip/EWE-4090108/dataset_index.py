from __future__ import annotations

import re
import copy
import math
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any, Sequence

from english_word_encoding_v22 import normalize


@dataclass(frozen=True)
class WordOccurrence:
    dataset_id: str
    record_id: str
    word: str
    identity: int
    position: int
    source_location: str | None


@dataclass(frozen=True)
class SequenceOccurrence:
    dataset_id: str
    record_id: str
    sequence: tuple[int, ...]
    positions: tuple[int, ...]
    source_location: str | None


class DatasetIndex:
    """Index encoded words and ordered token sequences for fast lookup."""

    def __init__(
        self,
        dataset_id: str,
        *,
        source: str | None = None,
        dictionary_reference: Any | None = None,
        max_sequence_length: int = 4,
    ) -> None:
        self.dataset_id = dataset_id
        self.source = source
        self.dictionary_reference = dictionary_reference
        self.max_sequence_length = max(1, max_sequence_length)
        self.word_occurrences: dict[int, list[WordOccurrence]] = defaultdict(list)
        self.sequence_occurrences: dict[tuple[int, tuple[int, ...]], list[SequenceOccurrence]] = defaultdict(list)
        self.record_word_counts: dict[str, dict[int, int]] = defaultdict(dict)
        self.record_text: dict[str, str] = {}
        self.record_locations: dict[str, str | None] = {}
        self.record_time_values: dict[str, dict[str, Any]] = {}
        self.record_term_frequency: dict[str, dict[int, int]] = defaultdict(dict)
        self.word_record_sets: dict[int, set[str]] = defaultdict(set)
        self.word_statistics: dict[int, dict[str, int]] = {}
        self.index_version = "dataset-index-v3"
        self.dataset_version: str | None = None
        self.last_synchronized_version: str | None = None
        self.last_applied_change_id: int | None = None
        self.history_generation: str | None = None
        self.sync_state = "uninitialized"
        self.full_rebuild_count = 0
        self.incremental_sync_count = 0
        self.noop_sync_count = 0
        self.last_sync_mode: str | None = None
        self.last_sync_reason: str | None = None
        self.ingestion_log: list[dict[str, Any]] = []

    @staticmethod
    def _tokenize_text(text: str) -> list[str]:
        if not isinstance(text, str):
            return []
        return re.findall(r"[A-Za-z]+", text.lower())

    @staticmethod
    def _extract_text(content: Any) -> str:
        if isinstance(content, str):
            return content
        if isinstance(content, dict):
            if "text" in content and isinstance(content["text"], str):
                return content["text"]
            rendered = []
            for key, value in content.items():
                rendered.append(str(key))
                rendered.append(str(value))
            return " ".join(rendered)
        if isinstance(content, (list, tuple)):
            return " ".join(str(item) for item in content)
        return str(content)

    def _encode_token(self, token: str) -> int:
        if self.dictionary_reference is None:
            raise ValueError("dictionary_reference is required to encode indexed tokens")
        entry = self.dictionary_reference.lookup(token)
        if entry is None:
            raise KeyError(f"unsupported token: {token!r}")
        return entry.identity

    @property
    def document_count(self) -> int:
        return len(self.record_text)

    def _clear_term_statistics(self) -> None:
        self.word_occurrences.clear()
        self.sequence_occurrences.clear()
        self.record_word_counts.clear()
        self.record_term_frequency.clear()
        self.word_record_sets.clear()
        self.word_statistics.clear()
        self.record_text.clear()
        self.record_locations.clear()
        self.record_time_values.clear()
        self.ingestion_log.clear()

    @staticmethod
    def _coerce_numeric(value: Any) -> float | None:
        if isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            try:
                numeric = float(value)
            except OverflowError:
                return None
            return numeric if math.isfinite(numeric) else None
        if isinstance(value, str):
            text = value.strip()
            if not text:
                return None
            try:
                numeric = float(text)
                return numeric if math.isfinite(numeric) else None
            except (ValueError, OverflowError):
                return None
        return None

    @classmethod
    def _coerce_temporal(cls, value: Any) -> tuple[str, Any] | None:
        numeric = cls._coerce_numeric(value)
        if numeric is not None:
            return "number", numeric
        parsed: datetime | None = None
        if isinstance(value, datetime):
            parsed = value
        elif isinstance(value, date):
            parsed = datetime(value.year, value.month, value.day)
        elif isinstance(value, str):
            try:
                parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
            except ValueError:
                return None
        if parsed is None:
            return None
        if parsed.tzinfo is not None and parsed.utcoffset() is not None:
            parsed = parsed.astimezone(timezone.utc)
        return "date", parsed

    @classmethod
    def _validated_period(cls, period: Any) -> tuple[dict[str, Any], str, Any, Any]:
        bounds = cls._normalize_period(period)
        if bounds["start"] is None or bounds["end"] is None:
            raise ValueError("period requires explicit start and end boundaries")
        start = cls._coerce_temporal(bounds["start"])
        end = cls._coerce_temporal(bounds["end"])
        if start is None or end is None:
            raise ValueError("period boundaries must be finite numbers, dates, or ISO timestamps")
        if start[0] != end[0]:
            raise ValueError("period boundaries must use the same temporal type")
        if start[0] == "date":
            start_aware = start[1].tzinfo is not None and start[1].utcoffset() is not None
            end_aware = end[1].tzinfo is not None and end[1].utcoffset() is not None
            if start_aware != end_aware:
                raise ValueError("period boundaries cannot mix timezone-aware and naive dates")
        if start[1] > end[1]:
            raise ValueError("period start must not be after period end")
        return bounds, start[0], start[1], end[1]

    @staticmethod
    def _normalize_period(period: Any) -> dict[str, Any]:
        if isinstance(period, dict):
            start = period.get("start", period.get("from"))
            end = period.get("end", period.get("to"))
            return {"start": start, "end": end}
        if isinstance(period, (list, tuple)) and len(period) == 2:
            return {"start": period[0], "end": period[1]}
        return {"start": None, "end": None}

    def _extract_time_values(self, record: Any) -> dict[str, Any]:
        values: dict[str, Any] = {}
        if record is None:
            return values
        payload = getattr(record, "content", record)
        metadata = getattr(record, "metadata", {}) or {}
        sources: list[dict[str, Any]] = []
        if isinstance(payload, dict):
            sources.append(payload)
        if isinstance(metadata, dict):
            sources.append(metadata)
        for mapping in sources:
            for key in sorted(mapping):
                if key.lower() in {"year", "date", "timestamp", "time", "period"}:
                    values[key.lower()] = mapping[key]
        if isinstance(payload, dict) and payload.get("metadata") and isinstance(payload["metadata"], dict):
            values.update({key.lower(): value for key, value in payload["metadata"].items() if key.lower() in {"year", "date", "timestamp", "time", "period"}})
        return values

    def _resolve_identity(self, word_or_identity: str | int) -> int | None:
        if isinstance(word_or_identity, int):
            return word_or_identity
        if self.dictionary_reference is None:
            return None
        entry = self.dictionary_reference.lookup(word_or_identity)
        return None if entry is None else entry.identity

    def _update_word_statistics(self, record_id: str, counts: dict[int, int], *, add: bool) -> None:
        if add:
            for identity, count in counts.items():
                stats = self.word_statistics.setdefault(identity, {"collection_frequency": 0, "document_frequency": 0, "term_frequency": 0})
                stats["collection_frequency"] += count
                stats["term_frequency"] = stats["collection_frequency"]
                self.record_term_frequency[record_id][identity] = count
                if record_id not in self.word_record_sets[identity]:
                    self.word_record_sets[identity].add(record_id)
                    stats["document_frequency"] = len(self.word_record_sets[identity])
        else:
            for identity, count in list(self.record_term_frequency.get(record_id, {}).items()):
                stats = self.word_statistics.get(identity)
                if stats is None:
                    continue
                stats["collection_frequency"] = max(0, stats["collection_frequency"] - count)
                stats["term_frequency"] = stats["collection_frequency"]
                self.word_record_sets[identity].discard(record_id)
                stats["document_frequency"] = len(self.word_record_sets[identity])
                self.record_term_frequency[record_id].pop(identity, None)
                if stats["collection_frequency"] == 0 and not self.word_record_sets[identity]:
                    self.word_statistics.pop(identity, None)
                    self.word_record_sets.pop(identity, None)
            self.record_term_frequency.pop(record_id, None)

    def add_record(self, record: Any, *, source_location: str | None = None, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
        record_id = getattr(record, "record_id", None)
        if record_id is None:
            raise ValueError("record must expose .record_id")
        if record_id in self.record_text:
            self.remove_record(record_id)
        payload = getattr(record, "content", record)
        content_text = self._extract_text(payload)
        self.record_text[record_id] = content_text
        self.record_locations[record_id] = source_location or getattr(record, "source_location", None)
        self.record_time_values[record_id] = self._extract_time_values(record)
        metadata = metadata or getattr(record, "metadata", {}) or {}
        self.record_word_counts[record_id] = {}
        tokens = self._tokenize_text(content_text)
        for position, token in enumerate(tokens):
            try:
                identity = self._encode_token(token)
            except KeyError:
                continue
            occurrence = WordOccurrence(
                dataset_id=self.dataset_id,
                record_id=record_id,
                word=token,
                identity=identity,
                position=position,
                source_location=self.record_locations[record_id],
            )
            self.word_occurrences[identity].append(occurrence)
            self.record_word_counts[record_id][identity] = self.record_word_counts[record_id].get(identity, 0) + 1
        self._update_word_statistics(record_id, dict(self.record_word_counts[record_id]), add=True)
        for length in range(1, self.max_sequence_length + 1):
            for offset in range(0, len(tokens) - length + 1):
                sequence = []
                positions = []
                valid = True
                for delta in range(length):
                    token = tokens[offset + delta]
                    try:
                        identity = self._encode_token(token)
                    except KeyError:
                        valid = False
                        break
                    sequence.append(identity)
                    positions.append(offset + delta)
                if not valid:
                    continue
                key = (length, tuple(sequence))
                self.sequence_occurrences[key].append(
                    SequenceOccurrence(
                        dataset_id=self.dataset_id,
                        record_id=record_id,
                        sequence=tuple(sequence),
                        positions=tuple(positions),
                        source_location=self.record_locations[record_id],
                    )
                )
        self.ingestion_log.append({
            "record_id": record_id,
            "action": "add",
            "source_location": self.record_locations[record_id],
            "metadata": metadata,
        })
        return {"record_id": record_id, "token_count": len(tokens), "source_location": self.record_locations[record_id]}

    def remove_record(self, record_id: str) -> None:
        if record_id not in self.record_text:
            return
        self._update_word_statistics(record_id, dict(self.record_word_counts.get(record_id, {})), add=False)
        record_positions = [
            occurrence for occurrences in self.word_occurrences.values() for occurrence in occurrences if occurrence.record_id == record_id
        ]
        for occurrence in record_positions:
            bucket = self.word_occurrences[occurrence.identity]
            self.word_occurrences[occurrence.identity] = [item for item in bucket if item.record_id != record_id]
            if not self.word_occurrences[occurrence.identity]:
                del self.word_occurrences[occurrence.identity]
        for key, occurrences in list(self.sequence_occurrences.items()):
            trimmed = [item for item in occurrences if item.record_id != record_id]
            if trimmed:
                self.sequence_occurrences[key] = trimmed
            else:
                del self.sequence_occurrences[key]
        self.record_word_counts.pop(record_id, None)
        self.record_text.pop(record_id, None)
        self.record_locations.pop(record_id, None)
        self.record_time_values.pop(record_id, None)
        self.ingestion_log.append({"record_id": record_id, "action": "delete"})

    def update_record(self, record: Any, *, source_location: str | None = None, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
        record_id = getattr(record, "record_id", None)
        if record_id is None:
            raise ValueError("record must expose .record_id")
        self.remove_record(record_id)
        return self.add_record(record, source_location=source_location, metadata=metadata)

    def lookup_word(self, word_or_identity: str | int) -> list[WordOccurrence]:
        if isinstance(word_or_identity, int):
            return list(self.word_occurrences.get(word_or_identity, ()))
        normalized = normalize(word_or_identity)
        if self.dictionary_reference is None:
            return []
        entry = self.dictionary_reference.lookup(normalized)
        if entry is None:
            return []
        return list(self.word_occurrences.get(entry.identity, ()))

    def lookup_sequence(self, sequence: Sequence[str | int]) -> list[SequenceOccurrence]:
        if not sequence:
            return []
        if self.dictionary_reference is None:
            return []
        encoded = []
        for item in sequence:
            if isinstance(item, int):
                encoded.append(item)
            else:
                entry = self.dictionary_reference.lookup(item)
                if entry is None:
                    return []
                encoded.append(entry.identity)
        key = (len(encoded), tuple(encoded))
        return list(self.sequence_occurrences.get(key, ()))

    @staticmethod
    def _snapshot_is_current(dataset_store: Any, snapshot: dict[str, Any]) -> bool:
        return (
            dataset_store.version == snapshot["version"]
            and dataset_store.change_counter == snapshot["change_counter"]
            and dataset_store.generation == snapshot["generation"]
        )

    @staticmethod
    def _journal_issue(snapshot: dict[str, Any], checkpoint: int | None) -> str | None:
        change_counter = snapshot["change_counter"]
        history_start = snapshot["history_start_change_id"]
        entries = snapshot["change_log"]
        if type(change_counter) is not int or change_counter < 0:
            return "invalid dataset change counter"
        if type(history_start) is not int or history_start < 1 or history_start > change_counter + 1:
            return "invalid change-history retention boundary"
        if checkpoint is None and history_start > 1:
            return f"history before retained change ID {history_start} is unavailable to an uninitialized index"
        expected = history_start
        seen: set[int] = set()
        for entry in entries:
            if not isinstance(entry, dict):
                return "malformed change event"
            change_id = entry.get("change_id")
            if type(change_id) is not int or change_id < 1:
                return "malformed change ID"
            if change_id in seen:
                return f"duplicate change ID {change_id}"
            seen.add(change_id)
            if change_id != expected:
                return f"change history gap or invalid order at change ID {expected}"
            if entry.get("generation") != snapshot["generation"]:
                return f"change event {change_id} belongs to another dataset generation"
            if entry.get("dataset_version") != f"dataset-v{change_id}":
                return f"change event {change_id} has an inconsistent dataset version"
            if entry.get("action") not in {"add", "update", "delete"}:
                return f"invalid action in change event {change_id}"
            if not isinstance(entry.get("record_id"), str) or not entry["record_id"]:
                return f"malformed record ID in change event {change_id}"
            expected += 1
        if expected != change_counter + 1:
            return f"change history is incomplete at change ID {expected}"
        if checkpoint is not None and checkpoint < history_start - 1:
            return f"required history through change ID {history_start - 1} was removed"
        return None

    def _commit_staged_index(self, staged: "DatasetIndex") -> None:
        self.__dict__.update(staged.__dict__)

    def _clone_for_transaction(self) -> "DatasetIndex":
        memo = {}
        if self.dictionary_reference is not None:
            memo[id(self.dictionary_reference)] = self.dictionary_reference
        return copy.deepcopy(self, memo)

    def _stage_rebuild(self, snapshot: dict[str, Any]) -> "DatasetIndex":
        staged = DatasetIndex(
            snapshot["dataset_id"],
            source=self.source,
            dictionary_reference=self.dictionary_reference,
            max_sequence_length=self.max_sequence_length,
        )
        staged.index_version = self.index_version
        staged.full_rebuild_count = self.full_rebuild_count
        staged.incremental_sync_count = self.incremental_sync_count
        staged.noop_sync_count = self.noop_sync_count
        for record in snapshot["records"].values():
            staged.add_record(
                record,
                source_location=getattr(record, "source_location", None),
                metadata=getattr(record, "metadata", {}),
            )
        staged.dataset_version = snapshot["version"]
        staged.last_synchronized_version = snapshot["version"]
        staged.last_applied_change_id = snapshot["change_counter"]
        staged.history_generation = snapshot["generation"]
        staged.sync_state = "synchronized"
        return staged

    def rebuild(self, dataset_store: Any) -> None:
        snapshot = dataset_store.snapshot()
        staged = self._stage_rebuild(snapshot)
        if not self._snapshot_is_current(dataset_store, snapshot):
            self.sync_state = "behind_dataset"
            raise RuntimeError("dataset changed while rebuilding the index; rebuild was not committed")
        staged.full_rebuild_count += 1
        staged.last_sync_mode = "rebuild"
        staged.last_sync_reason = "explicit"
        self._commit_staged_index(staged)

    def sync_from_store(self, dataset_store: Any, *, force: bool = False) -> dict[str, Any]:
        if self.dataset_id != dataset_store.dataset_id:
            self.sync_state = "inconsistent"
            raise ValueError(
                f"index dataset_id {self.dataset_id!r} does not match store {dataset_store.dataset_id!r}"
            )
        for attempt in range(2):
            snapshot = dataset_store.snapshot()
            current_version = snapshot["version"]
            checkpoint = self.last_applied_change_id
            if self.sync_state == "synchronized" and (
                self.dataset_version != current_version
                or checkpoint != snapshot["change_counter"]
                or self.history_generation != snapshot["generation"]
            ):
                self.sync_state = "behind_dataset"
            history_issue = self._journal_issue(snapshot, checkpoint)
            rebuild_reason: str | None = None
            if force:
                rebuild_reason = "forced"
            elif history_issue is not None:
                rebuild_reason = f"change_history_invalid: {history_issue}"
                self.sync_state = "missing_history"
            elif self.sync_state not in {"synchronized", "behind_dataset"} or self.last_synchronized_version is None:
                rebuild_reason = "uninitialized"
            elif self.history_generation != snapshot["generation"]:
                rebuild_reason = "dataset_generation_changed"
            elif checkpoint is None or checkpoint > snapshot["change_counter"]:
                rebuild_reason = "checkpoint_missing_or_ahead"
                self.sync_state = "inconsistent"
            elif self.dataset_version != self.last_synchronized_version:
                rebuild_reason = "index_checkpoint_inconsistent"
                self.sync_state = "inconsistent"
            elif self.dataset_version != current_version and checkpoint == snapshot["change_counter"]:
                rebuild_reason = "dataset_version_changed_without_events"
                self.sync_state = "inconsistent"

            try:
                if rebuild_reason is not None:
                    self.sync_state = "rebuilding"
                    staged = self._stage_rebuild(snapshot)
                    staged.full_rebuild_count += 1
                    rebuilt = True
                    records_synced = len(snapshot["records"])
                    mode = "rebuild"
                else:
                    pending_events = [
                        entry for entry in snapshot["change_log"]
                        if entry["change_id"] > checkpoint
                    ]
                    if pending_events and pending_events[0]["change_id"] != checkpoint + 1:
                        rebuild_reason = "required_change_history_missing"
                        staged = self._stage_rebuild(snapshot)
                        rebuilt = True
                        records_synced = len(snapshot["records"])
                        mode = "rebuild"
                    else:
                        staged = self._clone_for_transaction()
                        affected_records = {entry["record_id"] for entry in pending_events}
                        for record_id in affected_records:
                            record = snapshot["records"].get(record_id)
                            if record is None:
                                staged.remove_record(record_id)
                            else:
                                staged.remove_record(record_id)
                                staged.add_record(
                                    record,
                                    source_location=getattr(record, "source_location", None),
                                    metadata=getattr(record, "metadata", {}),
                                )
                        staged.dataset_version = current_version
                        staged.last_synchronized_version = current_version
                        staged.last_applied_change_id = snapshot["change_counter"]
                        staged.history_generation = snapshot["generation"]
                        staged.sync_state = "synchronized"
                        rebuilt = False
                        records_synced = len(affected_records)
                        mode = "incremental" if pending_events else "noop"
                        if pending_events:
                            staged.incremental_sync_count += 1
                        else:
                            staged.noop_sync_count += 1

                staged.last_sync_mode = mode
                staged.last_sync_reason = rebuild_reason

                if not self._snapshot_is_current(dataset_store, snapshot):
                    if attempt == 0:
                        continue
                    self.sync_state = "behind_dataset"
                    raise RuntimeError("dataset changed repeatedly during index synchronization")
                self._commit_staged_index(staged)
                return {
                    "synchronized": True,
                    "rebuilt": rebuilt,
                    "mode": mode,
                    "reason": rebuild_reason,
                    "history_issue": history_issue,
                    "records_synced": records_synced,
                    "dataset_version": current_version,
                    "checkpoint": snapshot["change_counter"],
                }
            except Exception:
                self.sync_state = "inconsistent"
                raise

    def build_index(self, dataset_store: Any) -> None:
        self.rebuild(dataset_store)

    def temporal_frequency(
        self,
        word_or_identity: str | int,
        *,
        time_field: str = "year",
        period: Any | None = None,
    ) -> dict[str, Any]:
        bounds, period_kind, start, end = self._validated_period(period)
        identity = self._resolve_identity(word_or_identity)
        if identity is None:
            return {
                "word": str(word_or_identity),
                "identity": None,
                "period": bounds,
                "frequency": 0,
                "document_frequency": 0,
                "observation_count": 0,
                "record_references": [],
                "warnings": ["Word is not present in the dictionary."],
            }

        period_records: list[str] = []
        missing_timestamp_count = 0
        invalid_timestamp_count = 0
        for record_id, time_values in self.record_time_values.items():
            value = time_values.get(time_field.lower()) if isinstance(time_values, dict) else None
            if value is None:
                missing_timestamp_count += 1
                continue
            temporal = self._coerce_temporal(value)
            if temporal is None:
                invalid_timestamp_count += 1
                continue
            if temporal[0] != period_kind:
                invalid_timestamp_count += 1
                continue
            if temporal[0] == "date":
                value_aware = temporal[1].tzinfo is not None and temporal[1].utcoffset() is not None
                start_aware = start.tzinfo is not None and start.utcoffset() is not None
                if value_aware != start_aware:
                    invalid_timestamp_count += 1
                    continue
            if temporal[1] < start or temporal[1] > end:
                continue
            period_records.append(record_id)
        frequency = sum(self.record_term_frequency.get(record_id, {}).get(identity, 0) for record_id in period_records)
        matching_records = [record_id for record_id in period_records if self.record_term_frequency.get(record_id, {}).get(identity, 0) > 0]
        document_frequency = len(matching_records)
        warnings = []
        if missing_timestamp_count:
            warnings.append(f"{missing_timestamp_count} records have no {time_field!r} value.")
        if invalid_timestamp_count:
            warnings.append(f"{invalid_timestamp_count} records have an invalid or incomparable {time_field!r} value.")
        return {
            "word": self.dictionary_reference.word_for_identity(identity) if self.dictionary_reference is not None and hasattr(self.dictionary_reference, "word_for_identity") else str(identity),
            "identity": identity,
            "period": bounds,
            "frequency": frequency,
            "document_frequency": document_frequency,
            "observation_count": len(period_records),
            "missing_timestamp_count": missing_timestamp_count,
            "invalid_timestamp_count": invalid_timestamp_count,
            "coverage_complete": missing_timestamp_count == 0 and invalid_timestamp_count == 0,
            "record_references": period_records,
            "matching_record_references": matching_records,
            "warnings": warnings,
        }

    def compare_period_frequency(
        self,
        word_or_identity: str | int,
        *,
        previous_period: Any,
        current_period: Any,
        time_field: str = "year",
    ) -> dict[str, Any]:
        identity = self._resolve_identity(word_or_identity)
        self._validated_period(previous_period)
        self._validated_period(current_period)
        previous_stats = self.temporal_frequency(word_or_identity, time_field=time_field, period=previous_period)
        current_stats = self.temporal_frequency(word_or_identity, time_field=time_field, period=current_period)
        absolute_change = current_stats["frequency"] - previous_stats["frequency"]
        relative_change = None
        if previous_stats["frequency"] not in (0, None):
            relative_change = absolute_change / previous_stats["frequency"]
        warnings: list[str] = []
        warnings.extend(previous_stats.get("warnings", []))
        warnings.extend(current_stats.get("warnings", []))
        if previous_period is None or current_period is None:
            warnings.append("Temporal comparison requires explicit period boundaries.")
        if previous_stats["observation_count"] == 0 and current_stats["observation_count"] == 0:
            warnings.append("No observations were available in either period.")
        if previous_stats["frequency"] == 0 and current_stats["frequency"] == 0:
            warnings.append("The word frequency is zero in both periods; relative change is undefined.")
        if previous_stats["frequency"] == 0 and current_stats["frequency"] != 0:
            warnings.append("Previous frequency was zero; relative change is undefined as a ratio against zero.")
        return {
            "word": previous_stats.get("word") or str(word_or_identity),
            "identity": identity,
            "previous_period": self._normalize_period(previous_period),
            "current_period": self._normalize_period(current_period),
            "time_field": time_field,
            "count_definition": "term occurrence frequency within inclusive period boundaries",
            "previous_frequency": previous_stats["frequency"],
            "current_frequency": current_stats["frequency"],
            "previous_observation_count": previous_stats["observation_count"],
            "current_observation_count": current_stats["observation_count"],
            "absolute_change": absolute_change,
            "relative_change": relative_change,
            "data_quality_warnings": warnings,
            "coverage_complete": previous_stats.get("coverage_complete", False) and current_stats.get("coverage_complete", False),
            "missing_timestamp_count": max(previous_stats.get("missing_timestamp_count", 0), current_stats.get("missing_timestamp_count", 0)),
            "invalid_timestamp_count": max(previous_stats.get("invalid_timestamp_count", 0), current_stats.get("invalid_timestamp_count", 0)),
            "record_references": {
                "previous": previous_stats["record_references"],
                "current": current_stats["record_references"],
            },
        }

    def frequency_change(self, *args, **kwargs) -> dict[str, Any]:
        return self.compare_period_frequency(*args, **kwargs)

    def compare_time_periods(self, *args, **kwargs) -> dict[str, Any]:
        return self.compare_period_frequency(*args, **kwargs)

    def as_dict(self) -> dict[str, Any]:
        return {
            "dataset_id": self.dataset_id,
            "source": self.source,
            "index_version": self.index_version,
            "dataset_version": self.dataset_version,
            "document_count": self.document_count,
            "sync_state": self.sync_state,
            "last_applied_change_id": self.last_applied_change_id,
            "history_generation": self.history_generation,
            "full_rebuild_count": self.full_rebuild_count,
            "incremental_sync_count": self.incremental_sync_count,
            "noop_sync_count": self.noop_sync_count,
            "word_statistics": {
                str(identity): {
                    "collection_frequency": stats.get("collection_frequency", 0),
                    "document_frequency": stats.get("document_frequency", 0),
                    "term_frequency": stats.get("term_frequency", 0),
                }
                for identity, stats in sorted(self.word_statistics.items())
            },
            "word_occurrences": {
                str(identity): [
                    {
                        "record_id": occ.record_id,
                        "word": occ.word,
                        "position": occ.position,
                        "source_location": occ.source_location,
                    }
                    for occ in occurrences
                ]
                for identity, occurrences in sorted(self.word_occurrences.items())
            },
            "sequence_occurrences": {
                str(key): [
                    {
                        "record_id": occ.record_id,
                        "sequence": list(occ.sequence),
                        "positions": list(occ.positions),
                        "source_location": occ.source_location,
                    }
                    for occ in occurrences
                ]
                for key, occurrences in sorted(self.sequence_occurrences.items(), key=lambda item: item[0])
            },
            "record_locations": self.record_locations,
            "word_record_sets": {
                str(identity): sorted(record_ids)
                for identity, record_ids in sorted(self.word_record_sets.items())
            },
            "record_word_counts": {
                record_id: dict(counts)
                for record_id, counts in sorted(self.record_word_counts.items())
            },
            "record_term_frequency": {
                record_id: dict(counts)
                for record_id, counts in sorted(self.record_term_frequency.items())
            },
            "record_time_values": self.record_time_values,
        }
