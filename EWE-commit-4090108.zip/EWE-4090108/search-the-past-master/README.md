# Search the Past

HTML widget for easily quearying previous date ranges for major search engines.

* You can [try it out](https://djsumdog.gitlab.io/search-the-past/).
* Read the [full blog post: Search the Past](https://battlepenguin.com/tech/search-the-past/).
* The HTML can be downloaded and run locally, or the version published here can be embedded in an `iframe` like so:

```
<div style="text-align:center;">
  <iframe src="https://djsumdog.gitlab.io/search-the-past/" title="Search the Past" style="width:800px;height:500px;margin-left: auto;margin-right:auto;">
  </iframe>
</div>
```