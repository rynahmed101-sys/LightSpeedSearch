import unittest
from unittest.mock import patch

from dataset_store import DatasetStore
from dictionary_reference import DictionaryReference
from verification_engine import VerificationEngine, VerificationStatus


class IntegrationTests(unittest.TestCase):
    def test_dictionary_reference_tracks_versions_and_round_trips(self):
        dictionary = DictionaryReference(
            source="demo-source",
            version="demo-v1",
            license="demo-license",
            acquisition_details="supplied by test",
            words=["cat", "dog", "horse", "cat"],
        )
        self.assertEqual(dictionary.identity_for("cat"), 2234)
        self.assertEqual(dictionary.word_for_identity(2234), "cat")
        self.assertTrue(dictionary.contains("DOG"))
        self.assertEqual(dictionary.metadata["source"], "demo-source")
        self.assertEqual(dictionary.metadata["version"], "demo-v1")

    def test_dataset_store_handles_incremental_updates(self):
        dataset = DatasetStore("dataset-1", source="synthetic")
        dataset.add_record("r1", {"year": 2021, "revenue": 100}, source_location="a")
        dataset.add_record("r2", {"year": 2022, "revenue": 120}, source_location="b")
        self.assertEqual(len(dataset.records), 2)
        dataset.update_record("r2", {"year": 2022, "revenue": 115}, source_location="b")
        self.assertEqual(dataset.get_record("r2").content["revenue"], 115)
        dataset.remove_record("r1")
        self.assertNotIn("r1", dataset.records)

    def test_verification_engine_rejects_contradictory_increase(self):
        dictionary = DictionaryReference(
            source="demo",
            version="v1",
            words=["revenue", "year", "through", "increased", "from", "every"],
        )
        dataset = DatasetStore("demo-revenue", source="synthetic")
        for year, amount in [(2021, 100), (2022, 120), (2023, 115)]:
            dataset.add_record(f"r{year}", {"year": year, "revenue": amount, "source_location": f"loc-{year}"}, source_location=f"loc-{year}")

        engine = VerificationEngine(dictionary_reference=dictionary)
        result = engine.verify_query(
            dataset,
            "Revenue increased every year from 2021 through 2023.",
            {"type": "increasing_sequence", "field": "revenue"},
        )
        self.assertEqual(result.status, VerificationStatus.REFUTED)
        self.assertIn("unsatisfiable", result.message.lower())

    def test_verification_engine_accepts_valid_increase(self):
        dictionary = DictionaryReference(
            source="demo",
            version="v1",
            words=["revenue", "year", "through", "increased", "from", "every"],
        )
        dataset = DatasetStore("demo-revenue-valid", source="synthetic")
        for year, amount in [(2021, 100), (2022, 120), (2023, 135)]:
            dataset.add_record(f"r{year}", {"year": year, "revenue": amount, "source_location": f"loc-{year}"}, source_location=f"loc-{year}")

        engine = VerificationEngine(dictionary_reference=dictionary)
        result = engine.verify_query(
            dataset,
            "Revenue increased every year from 2021 through 2023.",
            {"type": "increasing_sequence", "field": "revenue"},
        )
        self.assertEqual(result.status, VerificationStatus.VERIFIED)

    def test_verification_engine_reports_inconclusive_when_data_missing(self):
        dictionary = DictionaryReference(
            source="demo",
            version="v1",
            words=["revenue", "year", "through", "increased", "from", "every"],
        )
        dataset = DatasetStore("demo-revenue-incomplete", source="synthetic")
        dataset.add_record("r2021", {"year": 2021, "revenue": 100, "source_location": "loc-2021"}, source_location="loc-2021")
        dataset.add_record("r2022", {"year": 2022, "revenue": 120, "source_location": "loc-2022"}, source_location="loc-2022")

        engine = VerificationEngine(dictionary_reference=dictionary)
        result = engine.verify_query(
            dataset,
            "Revenue increased every year from 2021 through 2023.",
            {"type": "increasing_sequence", "field": "revenue"},
        )
        self.assertEqual(result.status, VerificationStatus.INCONCLUSIVE)

    def test_ordering_is_deterministic_across_ingestion_order(self):
        dictionary = DictionaryReference(
            source="demo",
            version="v1",
            words=["revenue", "year", "through", "increased", "from", "every"],
        )
        for insertion_order in ([2021, 2022, 2023], [2023, 2021, 2022], [2022, 2023, 2021]):
            dataset = DatasetStore(f"demo-order-{len(insertion_order)}", source="synthetic")
            for year in insertion_order:
                amount = 100 + (year - 2021) * 20
                dataset.add_record(f"r{year}", {"year": year, "revenue": amount, "source_location": f"loc-{year}"}, source_location=f"loc-{year}")
            engine = VerificationEngine(dictionary_reference=dictionary)
            result = engine.verify_query(
                dataset,
                "Revenue increased every year from 2021 through 2023.",
                {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"},
            )
            self.assertEqual(result.status, VerificationStatus.VERIFIED)

    def test_dataset_index_tracks_frequency_statistics_incrementally(self):
        dictionary = DictionaryReference(source="demo", version="v1", words=["revenue", "year", "market"])
        dataset = DatasetStore("demo-stats", source="synthetic")
        dataset.add_record("r1", {"year": 2021, "revenue": 100, "market": "north"}, source_location="loc-1")
        dataset.add_record("r2", {"year": 2022, "revenue": 120, "market": "south"}, source_location="loc-2")
        index = __import__("dataset_index").DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)
        self.assertGreater(index.word_statistics[dictionary.identity_for("revenue")]["document_frequency"], 0)
        self.assertGreaterEqual(index.word_statistics[dictionary.identity_for("revenue")]["collection_frequency"], 2)
        dataset.remove_record("r1")
        dataset.sync_index(index)
        self.assertEqual(index.word_statistics[dictionary.identity_for("revenue")]["document_frequency"], 1)

    def test_incremental_index_matches_full_rebuild_after_randomized_updates(self):
        import random

        dictionary = DictionaryReference(source="demo", version="v1", words=["revenue", "year", "market", "north", "south", "growth"])
        seed = 7
        random.seed(seed)
        dataset = DatasetStore("demo-randomized", source="synthetic")
        for year in range(2020, 2025):
            dataset.add_record(f"r{year}", {"year": year, "revenue": 100 + year - 2020, "market": "north" if year % 2 == 0 else "south", "note": "growth"}, source_location=f"loc-{year}")

        incremental = __import__("dataset_index").DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(incremental)

        for _ in range(20):
            choice = random.choice(["add", "update", "delete"])
            if choice == "add" and len(dataset.records) < 12:
                year = 2030 + len(dataset.records)
                dataset.add_record(f"r{year}", {"year": year, "revenue": 1000 + len(dataset.records), "market": "north", "note": "growth"}, source_location=f"loc-{year}")
            elif choice == "update" and dataset.records:
                record_id = random.choice(list(dataset.records))
                record = dataset.get_record(record_id)
                dataset.update_record(record_id, {"year": record.content.get("year", 2020), "revenue": record.content.get("revenue", 0) + 50, "market": "south" if record.content.get("market") == "north" else "north", "note": "growth"}, source_location=record.source_location)
            elif choice == "delete" and dataset.records:
                record_id = random.choice(list(dataset.records))
                dataset.remove_record(record_id)
            dataset.sync_index(incremental)

        expected = __import__("dataset_index").DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        expected.rebuild(dataset)
        self.assertEqual(sorted(incidental.record_id for incidental in incremental.word_occurrences.values() for incidental in incidental), sorted(incidental.record_id for incidental in expected.word_occurrences.values() for incidental in incidental))
        self.assertEqual(incremental.word_statistics, expected.word_statistics)
        self.assertEqual(incremental.sequence_occurrences.keys(), expected.sequence_occurrences.keys())

    def test_temporal_frequency_reports_change_and_zero_baseline(self):
        dictionary = DictionaryReference(source="demo", version="v1", words=["revenue", "year"])
        dataset = DatasetStore("demo-temporal", source="synthetic")
        for year, revenue in [(2021, 100), (2022, 150), (2023, 150), (2024, 0)]:
            dataset.add_record(f"r{year}", {"year": year, "revenue": revenue}, source_location=f"loc-{year}")
        index = __import__("dataset_index").DatasetIndex(dataset.dataset_id, dictionary_reference=dictionary)
        dataset.sync_index(index)

        delta = index.compare_period_frequency("revenue", previous_period={"start": 2021, "end": 2022}, current_period={"start": 2023, "end": 2024}, time_field="year")
        self.assertEqual(delta["previous_frequency"], 2)
        self.assertEqual(delta["current_frequency"], 2)
        self.assertEqual(delta["absolute_change"], 0)

        zero_baseline = index.compare_period_frequency("revenue", previous_period={"start": 2025, "end": 2025}, current_period={"start": 2026, "end": 2026}, time_field="year")
        self.assertIsNone(zero_baseline["relative_change"])
        self.assertTrue(zero_baseline["data_quality_warnings"])

    def test_satisfiable_model_with_insufficient_evidence_is_inconclusive(self):
        dictionary = DictionaryReference(words=["revenue", "year"])
        dataset = DatasetStore("demo-insufficient-evidence")
        dataset.add_record("r2021", {"year": 2021, "revenue": 100})
        dataset.add_record("r2022", {"year": 2022, "revenue": 120})
        engine = VerificationEngine(dictionary_reference=dictionary)

        result = engine.verify_query(
            dataset,
            "revenue year",
            {
                "type": "increasing_sequence",
                "field": "revenue",
                "sort_by": "year",
                "required_evidence": 3,
            },
        )

        self.assertEqual(result.solver_outcome, "SATISFIABLE")
        self.assertEqual(result.status, VerificationStatus.INCONCLUSIVE)
        self.assertIn("does not establish", result.message)
        self.assertEqual(result.evidence_coverage["final_status"], "INCONCLUSIVE")

    def test_satisfiable_subset_cannot_verify_incomplete_dataset_scope(self):
        dictionary = DictionaryReference(words=["revenue", "year", "noise"])
        dataset = DatasetStore("demo-incomplete-scope")
        dataset.add_record("r2021", {"year": 2021, "revenue": 100})
        dataset.add_record("r2022", {"year": 2022, "revenue": 120})
        dataset.add_record("unretrieved", {"note": "noise"})
        engine = VerificationEngine(dictionary_reference=dictionary)

        result = engine.verify_query(
            dataset,
            "revenue year",
            {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"},
        )

        self.assertEqual(result.solver_outcome, "SATISFIABLE")
        self.assertEqual(result.status, VerificationStatus.INCONCLUSIVE)
        self.assertFalse(result.evidence_coverage["candidate_record_count"] == result.evidence_coverage["dataset_record_count"])

    def test_truncation_and_missing_numeric_evidence_are_not_truth_claims(self):
        dictionary = DictionaryReference(words=["revenue", "year"])
        dataset = DatasetStore("demo-truncated")
        for year, revenue in ((2021, 100), (2022, 120), (2023, 90)):
            dataset.add_record(f"r{year}", {"year": year, "revenue": revenue})
        engine = VerificationEngine(dictionary_reference=dictionary)
        truncated = engine.verify_query(
            dataset,
            "revenue year",
            {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"},
            max_candidates=1,
        )
        self.assertEqual(truncated.status, VerificationStatus.INCONCLUSIVE)
        self.assertTrue(truncated.evidence_coverage["truncated"])
        self.assertNotIn("r2023", {candidate["record_id"] for candidate in truncated.candidates})
        exhaustive = engine.verify_query(
            dataset,
            "revenue year",
            {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"},
            max_candidates=None,
        )
        self.assertEqual(exhaustive.status, VerificationStatus.REFUTED)

        missing = DatasetStore("demo-missing-number")
        missing.add_record("r2021", {"year": 2021, "revenue": 100})
        missing.add_record("r2022", {"year": 2022, "note": "revenue"})
        result = VerificationEngine(dictionary_reference=dictionary).verify_query(
            missing,
            "revenue year",
            {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"},
        )
        self.assertEqual(result.status, VerificationStatus.INCONCLUSIVE)
        self.assertIsNone(result.solver_outcome)
        self.assertIn("incomplete", result.message.lower())

        malformed = DatasetStore("demo-malformed-number")
        malformed.add_record("r2021", {"year": 2021, "revenue": 100})
        malformed.add_record("r2022", {"year": 2022, "revenue": "not-numeric"})
        malformed_result = VerificationEngine(dictionary_reference=dictionary).verify_query(
            malformed,
            "revenue year",
            {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"},
        )
        self.assertEqual(malformed_result.status, VerificationStatus.INCONCLUSIVE)
        self.assertIsNone(malformed_result.solver_outcome)

    def test_unsatisfiable_subset_with_insufficient_evidence_is_inconclusive(self):
        dictionary = DictionaryReference(words=["revenue", "year"])
        dataset = DatasetStore("demo-unsat-insufficient")
        dataset.add_record("r2021", {"year": 2021, "revenue": 120})
        dataset.add_record("r2022", {"year": 2022, "revenue": 100})
        result = VerificationEngine(dictionary_reference=dictionary).verify_query(
            dataset,
            "revenue year",
            {
                "type": "increasing_sequence",
                "field": "revenue",
                "sort_by": "year",
                "required_evidence": 3,
            },
        )
        self.assertEqual(result.solver_outcome, "UNSATISFIABLE")
        self.assertEqual(result.status, VerificationStatus.INCONCLUSIVE)

    def test_solver_retrieval_adapter_and_concurrent_mutation_failures_are_explicit(self):
        dictionary = DictionaryReference(words=["revenue", "year"])
        dataset = DatasetStore("demo-failures")
        dataset.add_record("r2021", {"year": 2021, "revenue": 100})
        dataset.add_record("r2022", {"year": 2022, "revenue": 120})
        condition = {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"}

        solver_engine = VerificationEngine(dictionary_reference=dictionary)
        with patch("verification_engine.ConstraintSolver", side_effect=RuntimeError("solver failure")):
            solver_error = solver_engine.verify_query(dataset, "revenue year", condition)
        self.assertEqual(solver_error.status, VerificationStatus.ERROR)
        self.assertEqual(solver_error.solver_outcome, "ERROR")

        retrieval_engine = VerificationEngine(dictionary_reference=dictionary)
        with patch("verification_engine.QueryLocator.locate", side_effect=RuntimeError("retrieval failure")):
            retrieval_error = retrieval_engine.verify_query(dataset, "revenue year", condition)
        self.assertEqual(retrieval_error.status, VerificationStatus.ERROR)
        self.assertIn("retrieval failed", retrieval_error.message.lower())

        malformed_engine = VerificationEngine(dictionary_reference=dictionary)
        with patch.object(malformed_engine.evidence_adapter, "build_solver_input", return_value=None):
            malformed = malformed_engine.verify_query(dataset, "revenue year", condition)
        self.assertEqual(malformed.status, VerificationStatus.ERROR)
        self.assertIn("malformed", malformed.message.lower())

        mutation_dataset = DatasetStore("demo-mutation-during-verification")
        mutation_dataset.add_record("r2021", {"year": 2021, "revenue": 100})
        mutation_dataset.add_record("r2022", {"year": 2022, "revenue": 120})
        mutation_engine = VerificationEngine(dictionary_reference=dictionary)
        original_build = mutation_engine.evidence_adapter.build_solver_input

        def mutate_while_adapting(*args, **kwargs):
            result = original_build(*args, **kwargs)
            mutation_dataset.add_record("r2023", {"year": 2023, "revenue": 130})
            return result

        with patch.object(mutation_engine.evidence_adapter, "build_solver_input", side_effect=mutate_while_adapting):
            mutation_result = mutation_engine.verify_query(mutation_dataset, "revenue year", condition)
        self.assertEqual(mutation_result.status, VerificationStatus.ERROR)
        self.assertIn("changed during verification", mutation_result.message)

    def test_unsupported_predicate_is_not_misreported_as_a_truth_result(self):
        dictionary = DictionaryReference(words=["revenue", "year"])
        dataset = DatasetStore("demo-unsupported")
        dataset.add_record("r1", {"year": 2021, "revenue": 100})
        dataset.add_record("r2", {"year": 2022, "revenue": 120})
        result = VerificationEngine(dictionary_reference=dictionary).verify_query(
            dataset,
            "revenue year",
            {"type": "nonlinear_unknown_predicate", "field": "revenue"},
        )
        self.assertEqual(result.status, VerificationStatus.UNSUPPORTED)

    def test_sequence_without_order_or_with_duplicate_order_is_inconclusive(self):
        dictionary = DictionaryReference(words=["revenue", "year"])
        unordered = DatasetStore("demo-unordered-sequence")
        unordered.add_record("r1", {"revenue": 100})
        unordered.add_record("r2", {"revenue": 120})
        no_order = VerificationEngine(dictionary_reference=dictionary).verify_query(
            unordered,
            "revenue",
            {"type": "increasing_sequence", "field": "revenue"},
        )
        self.assertEqual(no_order.status, VerificationStatus.INCONCLUSIVE)

        duplicate_period = DatasetStore("demo-duplicate-period")
        duplicate_period.add_record("r1", {"year": 2021, "revenue": 100})
        duplicate_period.add_record("r2", {"year": 2021, "revenue": 120})
        duplicate_period.add_record("r3", {"year": 2022, "revenue": 130})
        ambiguous = VerificationEngine(dictionary_reference=dictionary).verify_query(
            duplicate_period,
            "revenue year",
            {"type": "increasing_sequence", "field": "revenue", "sort_by": "year"},
        )
        self.assertEqual(ambiguous.status, VerificationStatus.INCONCLUSIVE)
        self.assertIn("ambiguous", ambiguous.message)


if __name__ == "__main__":
    unittest.main()
