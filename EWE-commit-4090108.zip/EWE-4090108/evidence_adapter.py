from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, timezone
import math
from typing import Any, Mapping

from constraint_information import Constraint, SoftConstraint


def _normalize_condition(condition: Any) -> dict[str, Any]:
    if condition is None:
        return {"type": "unsupported", "predicate": "unsupported"}
    if hasattr(condition, "as_mapping"):
        mapped = condition.as_mapping()
        if isinstance(mapped, Mapping):
            return dict(mapped)
    if hasattr(condition, "to_dict"):
        mapped = condition.to_dict()
        if isinstance(mapped, Mapping):
            return dict(mapped)
    if isinstance(condition, Mapping):
        return dict(condition)
    if isinstance(condition, str):
        lowered = condition.lower().strip()
        if not lowered:
            return {"type": "unsupported", "predicate": "unsupported"}
        if any(token in lowered for token in ("increase", "rising", "grow")):
            return {"type": "increasing_sequence", "predicate": "increase", "field": "value"}
        if any(token in lowered for token in ("decrease", "fall", "drop")):
            return {"type": "decreasing_sequence", "predicate": "decrease", "field": "value"}
        return {"type": "unsupported", "predicate": lowered, "raw": condition}
    return {"type": "unsupported", "predicate": "unsupported", "raw": condition}


@dataclass
class AdapterResult:
    domains: dict[str, tuple[Any, ...]]
    constraints: list[Constraint]
    soft_constraints: list[SoftConstraint]
    evidence: list[dict[str, Any]]
    unresolved: list[str]
    unsupported: bool = False


class EvidenceAdapter:
    """Translate located evidence into solver inputs."""

    def __init__(self, dictionary_reference: Any | None = None) -> None:
        self.dictionary_reference = dictionary_reference

    @staticmethod
    def _coerce_numeric(value: Any) -> float | None:
        if isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            try:
                numeric = float(value)
            except OverflowError:
                return None
            return numeric if math.isfinite(numeric) else None
        if isinstance(value, str):
            text = value.strip()
            if not text:
                return None
            if re.fullmatch(r"[-+]?\d+(?:\.\d+)?", text):
                numeric = float(text)
                return numeric if math.isfinite(numeric) else None
        return None

    @staticmethod
    def _resolve_path(mapping: Mapping[str, Any], field: str) -> Any:
        if field in mapping:
            return mapping[field]
        if "." in field:
            current: Any = mapping
            for part in field.split("."):
                if not isinstance(current, Mapping):
                    return None
                if part in current:
                    current = current[part]
                else:
                    return None
            return current
        return None

    @classmethod
    def _field_value(cls, record: Mapping[str, Any], field: str) -> Any:
        if field in record:
            return record[field]
        content = record.get("content")
        if isinstance(content, Mapping):
            value = cls._resolve_path(content, field)
            if value is not None:
                return value
        metadata = record.get("metadata")
        if isinstance(metadata, Mapping):
            value = cls._resolve_path(metadata, field)
            if value is not None:
                return value
        for nested_name in ("content", "metadata"):
            nested_value = record.get(nested_name)
            if isinstance(nested_value, Mapping):
                direct = nested_value.get(field)
                if direct is not None:
                    return direct
        return None

    @classmethod
    def ordering_identity(cls, value: Any) -> tuple[str, Any] | None:
        if value is None:
            return None
        numeric = cls._coerce_numeric(value)
        if numeric is not None:
            return "number", numeric
        parsed: datetime | None = None
        if isinstance(value, datetime):
            parsed = value
        elif isinstance(value, date):
            parsed = datetime(value.year, value.month, value.day)
        elif isinstance(value, str):
            try:
                parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError:
                return "string", value
        if parsed is not None:
            if parsed.tzinfo is not None and parsed.utcoffset() is not None:
                parsed = parsed.astimezone(timezone.utc)
            return "date", parsed
        if isinstance(value, str):
            return "string", value
        raise ValueError(f"Unsupported ordering value: {value!r}")

    def _sort_evidence(
        self,
        evidence_records: list[dict[str, Any]],
        sort_key: str | None,
        *,
        descending: bool = False,
    ) -> list[tuple[str, Any]]:
        if sort_key is None:
            return sorted(
                ((str(record.get("record_id") or record.get("id") or "record"), record) for record in evidence_records),
                key=lambda item: item[0],
            )
        typed_values: list[tuple[str, Any, Any, int]] = []
        kinds: set[str] = set()
        timezone_awareness: set[bool] = set()
        for position, record in enumerate(evidence_records):
            record_id = str(record.get("record_id") or record.get("id") or "record")
            value = self._field_value(record, sort_key)
            if value is None:
                typed_values.append((record_id, None, record, position))
                continue
            numeric = self._coerce_numeric(value)
            if numeric is not None:
                kinds.add("number")
                typed_values.append((record_id, ("number", numeric), record, position))
                continue
            parsed: datetime | None = None
            if isinstance(value, datetime):
                parsed = value
            elif isinstance(value, date):
                parsed = datetime(value.year, value.month, value.day)
            elif isinstance(value, str):
                try:
                    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
                except (ValueError, OverflowError):
                    parsed = None
            if parsed is not None:
                aware = parsed.tzinfo is not None and parsed.utcoffset() is not None
                timezone_awareness.add(aware)
                if aware:
                    parsed = parsed.astimezone(timezone.utc)
                kinds.add("date")
                typed_values.append((record_id, ("date", parsed), record, position))
                continue
            if isinstance(value, str):
                kinds.add("string")
                typed_values.append((record_id, ("string", value), record, position))
                continue
            raise ValueError(f"Ordering field {sort_key!r} has an unsupported value for record {record_id!r}: {value!r}")

        if len(kinds) > 1:
            raise ValueError(f"Ordering field {sort_key!r} contains mixed supported types: {sorted(kinds)}")
        if len(timezone_awareness) > 1:
            raise ValueError(f"Ordering field {sort_key!r} mixes timezone-aware and naive dates")
        nonmissing = [item for item in typed_values if item[1] is not None]
        missing = [item for item in typed_values if item[1] is None]
        nonmissing.sort(key=lambda item: (item[0], item[3]))
        nonmissing.sort(key=lambda item: item[1][1], reverse=descending)
        missing.sort(key=lambda item: (item[0], item[3]))
        return [(record_id, record) for record_id, _, record, _ in nonmissing + missing]

    def _collect_values(self, records: list[dict[str, Any]], field: str | None = None) -> list[tuple[str, Any]]:
        collected: list[tuple[str, Any]] = []
        for record in records:
            if not isinstance(record, Mapping):
                continue
            payload = dict(record)
            chosen = self._field_value(payload, field) if field else None
            if chosen is not None:
                collected.append((str(payload.get("record_id", "record")), chosen))
            elif field is None and "value" in payload:
                collected.append((str(payload.get("record_id", "record")), payload["value"]))
            elif field is None and "revenue" in payload:
                collected.append((str(payload.get("record_id", "record")), payload["revenue"]))
            elif field is None and "amount" in payload:
                collected.append((str(payload.get("record_id", "record")), payload["amount"]))
        return collected

    def build_solver_input(
        self,
        query: str,
        verification_condition: Any,
        candidates: list[dict[str, Any]],
        evidence_records: list[dict[str, Any]],
    ) -> AdapterResult:
        if not evidence_records:
            message = "No evidence was available for the supplied query."
            return AdapterResult({}, [], [], [], [message])

        condition = _normalize_condition(verification_condition)
        if not isinstance(condition, Mapping):
            return AdapterResult({}, [], [], [], ["Verification condition must be a mapping or string."], unsupported=True)

        condition_type = str(condition.get("type") or condition.get("predicate") or condition.get("kind") or "unsupported").lower()
        if condition_type in {"increase", "increasing", "rising", "growth"}:
            condition_type = "increasing_sequence"
        elif condition_type in {"decrease", "decreasing", "falling", "drop"}:
            condition_type = "decreasing_sequence"
        field = (
            condition.get("field")
            or condition.get("value_field")
            or condition.get("metric")
            or condition.get("subject")
            or "value"
        )
        sort_key = condition.get("sort_by") or condition.get("sort_key") or condition.get("ordering") or condition.get("order_by")
        descending = str(condition.get("sort_direction", "ascending")).lower() == "descending" or condition.get("descending") is True

        values: list[tuple[str, Any]] = []
        missing_value_records: list[str] = []
        for record in evidence_records:
            if not isinstance(record, Mapping):
                return AdapterResult(
                    {}, [], [], [], ["Evidence adapter received a malformed record."]
                )
            record_id = str(record.get("record_id") or record.get("id") or "record")
            value = self._field_value(record, field)
            if value is not None:
                values.append((record_id, value))
            else:
                missing_value_records.append(record_id)

        if missing_value_records:
            message = f"Required field {field!r} is missing for record(s): {', '.join(sorted(missing_value_records))}."
            return AdapterResult({}, [], [], [], [message])
        if not values:
            message = "No numeric evidence matched the requested condition."
            return AdapterResult({}, [], [], [], [message])

        if sort_key:
            try:
                ordered = self._sort_evidence(evidence_records, sort_key, descending=descending)
                if any(self._field_value(record, sort_key) is None for _, record in ordered):
                    return AdapterResult(
                        {}, [], [], [], [f"Ordering field {sort_key!r} is missing for one or more records."]
                    )
                values = [
                    (record_id, self._field_value(record, field))
                    for record_id, record in ordered
                    if self._field_value(record, field) is not None
                ]
            except ValueError as exc:
                return AdapterResult({}, [], [], [], [str(exc)])

        numeric_values: list[tuple[str, float]] = []
        for record_id, raw_value in values:
            numeric = self._coerce_numeric(raw_value)
            if numeric is None:
                return AdapterResult({}, [], [], [], [f"Evidence value for {record_id!r} is not numeric."])
            numeric_values.append((record_id, numeric))

        if condition_type in {"increasing_sequence", "strictly_increasing", "greater_than_next"}:
            if len(numeric_values) < 2:
                return AdapterResult({}, [], [], [], ["Increasing-sequence verification needs at least two numeric values."])
            domains: dict[str, tuple[Any, ...]] = {}
            constraints: list[Constraint] = []
            for index, (_, numeric_value) in enumerate(numeric_values):
                var_name = f"value_{index}"
                domains[var_name] = (numeric_value,)
            for index in range(len(numeric_values) - 1):
                left = f"value_{index}"
                right = f"value_{index + 1}"
                constraints.append(
                    Constraint(
                        (left, right),
                        lambda left_value, right_value: left_value < right_value,
                        name=f"increasing_{index}",
                    )
                )
            return AdapterResult(domains, constraints, [], [{"record_id": record_id, "value": value} for record_id, value in numeric_values], [])

        if condition_type in {"decreasing_sequence", "strictly_decreasing", "less_than_next"}:
            if len(numeric_values) < 2:
                return AdapterResult({}, [], [], [], ["Decreasing-sequence verification needs at least two numeric values."])
            domains = {}
            constraints = []
            for index, (_, numeric_value) in enumerate(numeric_values):
                var_name = f"value_{index}"
                domains[var_name] = (numeric_value,)
            for index in range(len(numeric_values) - 1):
                left = f"value_{index}"
                right = f"value_{index + 1}"
                constraints.append(
                    Constraint(
                        (left, right),
                        lambda left_value, right_value: left_value > right_value,
                        name=f"decreasing_{index}",
                    )
                )
            return AdapterResult(domains, constraints, [], [{"record_id": record_id, "value": value} for record_id, value in numeric_values], [])

        return AdapterResult({}, [], [], [], [f"Unsupported verification condition: {condition_type}"], unsupported=True)


def build_evidence_adapter(dictionary_reference: Any | None = None) -> EvidenceAdapter:
    return EvidenceAdapter(dictionary_reference)
