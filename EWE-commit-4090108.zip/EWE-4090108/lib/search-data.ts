export type ResultView = "Consensus" | "Unique Discoveries" | "Hidden Trails" | "Historical Results" | "Unresolved Differences";

export type SearchResult = {
  id: string;
  title: string;
  url: string;
  provider: string;
  snippet: string;
  score: number;
  view: ResultView;
  category: string;
  discoveryState: string;
  verificationState: string;
  date: string;
  sourceType: string;
  evidence: string[];
};

export const searchResults: SearchResult[] = [
  {
    id: 'r1',
    title: 'Dictionary-based word identity and evidence coverage',
    url: 'https://example.com/ewe-identity',
    provider: 'EWE Lexicon',
    snippet: 'Normalized ASCII spelling identity is preserved distinctly from semantic meaning and is used as the stable dictionary foundation.',
    score: 0.97,
    view: 'Consensus',
    category: 'Dictionary reference',
    discoveryState: 'Indexed',
    verificationState: 'Supported by inspected evidence',
    date: '2024-08-12',
    sourceType: 'Reference',
    evidence: ['dictionary record', 'stable identity mapping'],
  },
  {
    id: 'r2',
    title: 'WordNet lexical relationships and their scope limits',
    url: 'https://example.com/wordnet-scope',
    provider: 'WordNet archive',
    snippet: 'WordNet data enriches the available word relationships without equating spelling identity with meaning or truth.',
    score: 0.91,
    view: 'Hidden Trails',
    category: 'Lexical graph',
    discoveryState: 'Retrieved',
    verificationState: 'Not assessed',
    date: '2024-09-18',
    sourceType: 'Dataset',
    evidence: ['synset metadata', 'lexical relation references'],
  },
  {
    id: 'r3',
    title: 'Search the Past historical query adapters',
    url: 'https://example.com/search-the-past',
    provider: 'Search the Past',
    snippet: 'Date-bounded historical searches are generated for provider-specific query strings while retaining provider attribution and source metadata.',
    score: 0.89,
    view: 'Historical Results',
    category: 'Historical search',
    discoveryState: 'Parsed',
    verificationState: 'Partially assessed',
    date: '2024-10-03',
    sourceType: 'UI adapter',
    evidence: ['provider URL generation', 'year-range filtering'],
  },
  {
    id: 'r4',
    title: 'LSS local search engine and candidate ranking',
    url: 'https://example.com/lss-local-search',
    provider: 'LSS',
    snippet: 'Local document indexing and ranking operations remain inspectable and separate from any claim-level verification outcome.',
    score: 0.88,
    view: 'Unique Discoveries',
    category: 'Retrieval engine',
    discoveryState: 'Discovered',
    verificationState: 'Evidence found',
    date: '2024-11-01',
    sourceType: 'Search engine',
    evidence: ['term weighting', 'document ranking'],
  },
  {
    id: 'r5',
    title: 'Verification status stays distinct from search discovery',
    url: 'https://example.com/evidence-status',
    provider: 'Verification engine',
    snippet: 'A SAT or UNSAT result is only meaningful relative to the formal model and premises checked; it is not proof of a real-world claim.',
    score: 0.85,
    view: 'Unresolved Differences',
    category: 'Evidence workflow',
    discoveryState: 'Related sources found',
    verificationState: 'Conflicting evidence',
    date: '2024-07-21',
    sourceType: 'Policy',
    evidence: ['solver output', 'evidence coverage'],
  },
];

export const activeViews: ResultView[] = [
  'Consensus',
  'Unique Discoveries',
  'Hidden Trails',
  'Historical Results',
  'Unresolved Differences',
];

export function runLocalQuery(query: string): SearchResult[] {
  const normalized = query.trim().toLowerCase();
  if (!normalized) {
    return searchResults;
  }

  const tokens = normalized.split(/\s+/);
  return searchResults.filter((item) => {
    const haystack = [
      item.title,
      item.provider,
      item.snippet,
      item.category,
      item.discoveryState,
      item.verificationState,
      ...item.evidence,
    ]
      .join(' ')
      .toLowerCase();

    return tokens.every((token) => haystack.includes(token));
  });
}
