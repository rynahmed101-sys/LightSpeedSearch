from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Sequence


@dataclass(frozen=True)
class CandidateLocation:
    dataset_id: str
    record_id: str
    source_location: str | None
    matched_terms: tuple[str, ...]
    score: float
    match_type: str
    positions: tuple[int, ...]
    context: str
    explanation: str = ""


class QueryLocator:
    """Use the dictionary and occurrence index to narrow query candidates."""

    def __init__(self, dictionary_reference: Any, dataset_index: Any) -> None:
        self.dictionary_reference = dictionary_reference
        self.dataset_index = dataset_index

    @staticmethod
    def tokenize_query(query: str) -> list[str]:
        return re.findall(r"[A-Za-z]+", query.lower())

    def _idf_for_identity(self, identity: int) -> float:
        if self.dataset_index is None:
            return 1.0
        stats = self.dataset_index.word_statistics.get(identity, {})
        document_frequency = int(stats.get("document_frequency", 0))
        document_count = max(1, getattr(self.dataset_index, "document_count", 0))
        return math.log(1.0 + ((document_count + 1.0) / (document_frequency + 1.0)))

    def _rank_terms(self, token: str, occurrences: list[Any], candidate_map: dict[str, dict[str, Any]]) -> None:
        for occurrence in occurrences:
            record_key = occurrence.record_id
            entry = candidate_map.setdefault(
                record_key,
                {
                    "dataset_id": occurrence.dataset_id,
                    "record_id": record_key,
                    "source_location": occurrence.source_location,
                    "matched_terms": set(),
                    "positions": set(),
                    "match_types": set(),
                    "score": 0.0,
                    "context": self.dataset_index.record_text.get(record_key, ""),
                    "explanations": [],
                },
            )
            entry["matched_terms"].add(token)
            entry["positions"].add(occurrence.position)
            entry["match_types"].add("word")
            term_frequency = self.dataset_index.record_term_frequency.get(record_key, {}).get(occurrence.identity, 0)
            idf_value = self._idf_for_identity(occurrence.identity)
            score_gain = idf_value * (1.0 + math.log1p(term_frequency))
            entry["score"] += score_gain
            entry["explanations"].append(f"{token}: idf={idf_value:.3f}, tf={term_frequency}")

    def locate(
        self,
        query: str,
        *,
        max_candidates: int | None = 10,
        sequence_length: int = 3,
        exact_only: bool = False,
        retrieval_mode: str = "exploratory",
        field_filters: dict[str, Any] | None = None,
        evidence_requirements: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        tokens = self.tokenize_query(query)
        supported = []
        unknown = []
        for token in tokens:
            if self.dictionary_reference.lookup(token) is not None:
                supported.append(token)
            else:
                unknown.append(token)

        if not supported:
            return {
                "query": query,
                "tokens": tokens,
                "supported_tokens": [],
                "unknown_tokens": unknown,
                "candidates": [],
                "retrieval_mode": retrieval_mode,
                "truncated": False,
                "plan": {"mode": retrieval_mode, "reason": "no_supported_tokens"},
            }

        candidates: dict[str, dict[str, Any]] = {}
        for token in supported:
            occurrences = self.dataset_index.lookup_word(token)
            if occurrences:
                self._rank_terms(token, occurrences, candidates)

        if not exact_only:
            for start in range(len(supported)):
                for length in range(2, min(len(supported) - start, sequence_length) + 1):
                    phrase = tuple(supported[start:start + length])
                    if len(phrase) < 2:
                        continue
                    sequence = tuple(self.dictionary_reference.encode(token) for token in phrase)
                    matches = self.dataset_index.lookup_sequence(sequence)
                    if not matches:
                        continue
                    for match in matches:
                        entry = candidates.setdefault(
                            match.record_id,
                            {
                                "dataset_id": match.dataset_id,
                                "record_id": match.record_id,
                                "source_location": match.source_location,
                                "matched_terms": set(),
                                "positions": set(),
                                "match_types": set(),
                                "score": 0.0,
                                "context": self.dataset_index.record_text.get(match.record_id, ""),
                                "explanations": [],
                            },
                        )
                        entry["matched_terms"].update(phrase)
                        entry["positions"].update(match.positions)
                        entry["score"] += 2.5 * length
                        entry["match_types"].add("sequence")
                        entry["explanations"].append(f"phrase sequence {phrase}: bonus={2.5*length}")

        ranked = []
        for data in candidates.values():
            final_type = "|".join(sorted(data["match_types"]))
            explanation = "; ".join(data["explanations"]) if data["explanations"] else "matched query terms"
            ranked.append(
                CandidateLocation(
                    dataset_id=data["dataset_id"],
                    record_id=data["record_id"],
                    source_location=data["source_location"],
                    matched_terms=tuple(sorted(data["matched_terms"])),
                    score=float(data["score"]),
                    match_type=final_type,
                    positions=tuple(sorted(data["positions"])),
                    context=data["context"][:200],
                    explanation=explanation,
                )
            )
        ranked.sort(key=lambda item: (-item.score, item.record_id))
        truncated = max_candidates is not None and len(ranked) > max_candidates
        result = {
            "query": query,
            "tokens": tokens,
            "supported_tokens": supported,
            "unknown_tokens": unknown,
            "candidates": ranked if max_candidates is None else ranked[:max_candidates],
            "retrieval_mode": retrieval_mode,
            "truncated": truncated,
            "retrieval_exhaustive": True,
            "plan": {
                "mode": retrieval_mode,
                "candidate_limit": max_candidates,
                "query_terms": supported,
                "unknown_terms": unknown,
                "field_filters": field_filters,
                "evidence_requirements": evidence_requirements,
                "result_contract": "all lexical matches" if max_candidates is None else "bounded ranked candidates",
            },
        }
        if retrieval_mode == "verification" and truncated:
            result["verification_truncated"] = True
        return result
