from __future__ import annotations

import hashlib
import json
import copy
import uuid
from dataclasses import dataclass, field
from typing import Any, Iterator


@dataclass
class DatasetRecord:
    record_id: str
    content: Any
    source: str | None = None
    source_location: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    content_hash: str | None = None

    def __post_init__(self) -> None:
        if self.content_hash is None:
            payload = json.dumps(self.content, sort_keys=True, default=str)
            self.content_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()


class DatasetStore:
    """In-memory dataset store with incremental record tracking."""

    def __init__(self, dataset_id: str, source: str | None = None, version: str | None = None) -> None:
        self.dataset_id = dataset_id
        self.source = source
        self.version = version or "dataset-v0"
        self.change_counter = 0
        self.generation = uuid.uuid4().hex
        self.history_start_change_id = 1
        self.records: dict[str, DatasetRecord] = {}
        self.deleted: set[str] = set()
        self.ingestion_log: list[dict[str, Any]] = []
        self.change_log: list[dict[str, Any]] = []
        self.last_indexed_version: str | None = None
        self.index_sync_state: dict[str, Any] = {
            "dataset_id": dataset_id,
            "dataset_version": self.version,
            "last_indexed_version": self.last_indexed_version,
            "synchronized": False,
            "state": "uninitialized",
        }

    def _bump_version(self) -> None:
        self.change_counter += 1
        self.version = f"dataset-v{self.change_counter}"
        self.index_sync_state["dataset_version"] = self.version
        self.index_sync_state["last_indexed_version"] = self.last_indexed_version
        self.index_sync_state["synchronized"] = False
        self.index_sync_state["state"] = "behind_dataset"

    def _record_change(self, action: str, record_id: str, **details: Any) -> None:
        entry = {
            "action": action,
            "record_id": record_id,
            "dataset_version": self.version,
            "change_id": self.change_counter,
            "generation": self.generation,
            **details,
        }
        self.ingestion_log.append(entry)
        self.change_log.append(entry)

    def snapshot(self) -> dict[str, Any]:
        """Return an isolated in-memory view of the dataset and its journal."""
        return {
            "dataset_id": self.dataset_id,
            "version": self.version,
            "change_counter": self.change_counter,
            "generation": self.generation,
            "history_start_change_id": self.history_start_change_id,
            "records": copy.deepcopy(self.records),
            "change_log": copy.deepcopy(self.change_log),
        }

    def clear_change_history(self) -> None:
        """Discard journal entries while retaining a detectable retention boundary."""
        self.change_log.clear()
        self.history_start_change_id = self.change_counter + 1

    def sync_index(self, index: Any | None = None) -> dict[str, Any]:
        if index is None:
            self.index_sync_state = {
                "dataset_id": self.dataset_id,
                "dataset_version": self.version,
                "last_indexed_version": self.last_indexed_version,
                "synchronized": False,
                "rebuilt": False,
                "state": "uninitialized",
            }
            return self.index_sync_state

        if hasattr(index, "sync_from_store"):
            try:
                result = index.sync_from_store(self)
            except Exception:
                self.index_sync_state = {
                    "dataset_id": self.dataset_id,
                    "dataset_version": self.version,
                    "last_indexed_version": self.last_indexed_version,
                    "synchronized": False,
                    "state": getattr(index, "sync_state", "inconsistent"),
                }
                raise
            synchronized = bool(result.get("synchronized", False))
            if synchronized:
                self.last_indexed_version = result.get("dataset_version", self.version)
            self.index_sync_state = {
                "dataset_id": self.dataset_id,
                "dataset_version": self.version,
                "last_indexed_version": self.last_indexed_version,
                "index_version": getattr(index, "index_version", None),
                "synchronized": synchronized and self.last_indexed_version == self.version,
                "rebuilt": bool(result.get("rebuilt", False)),
                "records_synced": result.get("records_synced", 0),
                "state": getattr(index, "sync_state", "inconsistent"),
                "mode": result.get("mode"),
                "reason": result.get("reason"),
            }
            return self.index_sync_state

        if not hasattr(index, "rebuild"):
            self.index_sync_state = {
                "dataset_id": self.dataset_id,
                "dataset_version": self.version,
                "last_indexed_version": self.last_indexed_version,
                "synchronized": False,
                "state": "inconsistent",
                "reason": "index does not expose a synchronization or rebuild method",
            }
            return self.index_sync_state
        index.rebuild(self)
        self.last_indexed_version = self.version
        self.index_sync_state = {
            "dataset_id": self.dataset_id,
            "dataset_version": self.version,
            "last_indexed_version": self.last_indexed_version,
            "index_version": getattr(index, "index_version", None),
            "synchronized": True,
            "rebuilt": True,
        }
        return self.index_sync_state

    def add_record(
        self,
        record_id: str,
        content: Any,
        *,
        source: str | None = None,
        source_location: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> DatasetRecord:
        record = DatasetRecord(
            record_id=record_id,
            content=content,
            source=source or self.source,
            source_location=source_location,
            metadata=metadata or {},
        )
        self.records[record_id] = record
        self.deleted.discard(record_id)
        self._bump_version()
        self._record_change(
            "add",
            record_id,
            content_hash=record.content_hash,
            source_location=source_location,
            source=source or self.source,
        )
        return record

    def update_record(
        self,
        record_id: str,
        content: Any,
        *,
        source: str | None = None,
        source_location: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> DatasetRecord:
        record = DatasetRecord(
            record_id=record_id,
            content=content,
            source=source or self.source,
            source_location=source_location,
            metadata=metadata or {},
        )
        current = self.records.get(record_id)
        self.records[record_id] = record
        self.deleted.discard(record_id)
        self._bump_version()
        self._record_change(
            "update",
            record_id,
            previous_hash=getattr(current, "content_hash", None),
            content_hash=record.content_hash,
            source_location=source_location,
            source=source or self.source,
        )
        return record

    def remove_record(self, record_id: str) -> None:
        previous = self.records.get(record_id)
        if record_id in self.records:
            del self.records[record_id]
        self.deleted.add(record_id)
        self._bump_version()
        self._record_change(
            "delete",
            record_id,
            previous_hash=getattr(previous, "content_hash", None),
            source_location=getattr(previous, "source_location", None),
        )

    def get_record(self, record_id: str) -> DatasetRecord | None:
        return self.records.get(record_id)

    def iter_records(self) -> Iterator[DatasetRecord]:
        yield from self.records.values()

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_id": self.dataset_id,
            "source": self.source,
            "version": self.version,
            "record_count": len(self.records),
            "records": {
                record_id: {
                    "record_id": record.record_id,
                    "source": record.source,
                    "source_location": record.source_location,
                    "metadata": record.metadata,
                    "content_hash": record.content_hash,
                    "content": record.content,
                }
                for record_id, record in self.records.items()
            },
            "ingestion_log": self.ingestion_log,
        }
